import React from 'react';
import { Eye, EyeOff, Search, Bell, Wallet, ShieldCheck } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenNotifications: () => void;
  onOpenAuth: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSearch, onOpenNotifications, onOpenAuth }) => {
  const { userProfile, updateUserProfile, isLoggedIn } = useFinance();

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md text-[#0F172A] dark:text-slate-100 border-b border-[#E2E8F0] dark:border-slate-800 shadow-xs transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#4F46E5] rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100 dark:shadow-none shrink-0">
            <div className="w-5 h-5 border-2 border-white rounded-sm rotate-45 flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-white rounded-full" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-xl text-[#0F172A] dark:text-white">
                MoneyTrack
              </span>
              <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-[#4F46E5] dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/50">
                BENTO
              </span>
            </div>
            <p className="text-[11px] text-[#64748B] dark:text-slate-400 font-medium hidden sm:block">
              Know Your Money. Control Your Future.
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* Privacy Eye Toggle */}
          <button
            onClick={() => updateUserProfile({ privacyMode: !userProfile.privacyMode })}
            title={userProfile.privacyMode ? 'Show Balances' : 'Hide Balances'}
            className="p-2.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-xl bg-[#F1F5F9] hover:bg-[#E2E8F0] dark:bg-slate-800 dark:hover:bg-slate-700 transition"
          >
            {userProfile.privacyMode ? (
              <EyeOff className="w-4 h-4 text-amber-500" />
            ) : (
              <Eye className="w-4 h-4" />
            )}
          </button>

          {/* Global Search */}
          <button
            onClick={onOpenSearch}
            title="Search Transactions"
            className="p-2.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-xl bg-[#F1F5F9] hover:bg-[#E2E8F0] dark:bg-slate-800 dark:hover:bg-slate-700 transition"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Notifications */}
          <button
            onClick={onOpenNotifications}
            title="Reminders & Notifications"
            className="p-2.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-xl bg-[#F1F5F9] hover:bg-[#E2E8F0] dark:bg-slate-800 dark:hover:bg-slate-700 transition relative"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#4F46E5] animate-pulse" />
          </button>

          {/* User Profile / Auth Button */}
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-full bg-[#F1F5F9] hover:bg-[#E2E8F0] dark:bg-slate-800 dark:hover:bg-slate-700 border border-[#E2E8F0] dark:border-slate-700 transition text-xs font-semibold text-[#0F172A] dark:text-slate-200"
          >
            <div className="w-6 h-6 rounded-full bg-[#4F46E5] text-white flex items-center justify-center font-bold text-[11px]">
              {userProfile.name.charAt(0).toUpperCase()}
            </div>
            <span className="max-w-[70px] truncate">
              {isLoggedIn ? userProfile.name.split(' ')[0] : 'Guest'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
