import React, { useState } from 'react';
import { Home, ArrowLeftRight, PieChart, BarChart3, User, Plus, ArrowUpRight, ArrowDownLeft, RefreshCw } from 'lucide-react';
import { TransactionType } from '../types';

interface NavigationProps {
  activeTab: 'home' | 'transactions' | 'budget' | 'reports' | 'profile';
  setActiveTab: (tab: 'home' | 'transactions' | 'budget' | 'reports' | 'profile') => void;
  onOpenQuickAdd: (type?: TransactionType) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab, onOpenQuickAdd }) => {
  const [showQuickAddMenu, setShowQuickAddMenu] = useState(false);

  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'transactions', label: 'Transactions', icon: ArrowLeftRight },
    { id: 'budget', label: 'Budget', icon: PieChart },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'profile', label: 'Profile', icon: User },
  ] as const;

  const handleQuickAddClick = (type: TransactionType) => {
    setShowQuickAddMenu(false);
    onOpenQuickAdd(type);
  };

  return (
    <>
      {/* Quick Add Overlay Menu when '+' is tapped */}
      {showQuickAddMenu && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-xs flex flex-col justify-end items-center pb-24 px-4 animate-fadeIn"
          onClick={() => setShowQuickAddMenu(false)}
        >
          <div
            className="w-full max-w-xs bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-2xl space-y-2 animate-slideUp"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-center text-xs font-semibold text-slate-400 uppercase tracking-wider py-1 border-b border-slate-800">
              Quick Add Transaction
            </div>

            <button
              onClick={() => handleQuickAddClick('expense')}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 transition group"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-rose-500 text-white flex items-center justify-center shadow-md">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <p className="font-bold text-sm text-slate-100">Add Expense</p>
                  <p className="text-xs text-slate-400">Food, Bills, Shopping, etc.</p>
                </div>
              </div>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300">
                - Outflow
              </span>
            </button>

            <button
              onClick={() => handleQuickAddClick('income')}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 transition group"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-emerald-500 text-white flex items-center justify-center shadow-md">
                  <ArrowDownLeft className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <p className="font-bold text-sm text-slate-100">Add Income</p>
                  <p className="text-xs text-slate-400">Salary, Freelance, Gift, etc.</p>
                </div>
              </div>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                + Inflow
              </span>
            </button>

            <button
              onClick={() => handleQuickAddClick('transfer')}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 transition group"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-indigo-500 text-white flex items-center justify-center shadow-md">
                  <RefreshCw className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <p className="font-bold text-sm text-slate-100">Transfer Funds</p>
                  <p className="text-xs text-slate-400">Move between Bank, Cash, Savings</p>
                </div>
              </div>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                ↔ Move
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Floating Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-[#E2E8F0] dark:border-slate-800 shadow-md transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between relative">
          {/* Left two tabs */}
          <div className="flex items-center justify-around flex-1 max-w-xs mx-auto md:max-w-none">
            {tabs.slice(0, 2).map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setShowQuickAddMenu(false);
                    setActiveTab(tab.id as any);
                  }}
                  className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition ${
                    isActive
                      ? 'text-[#4F46E5] dark:text-indigo-400 font-bold scale-105'
                      : 'text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-slate-200 font-semibold'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
                  <span className="text-[10px] mt-1 tracking-tight">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Center Floating Quick Add '+' Button */}
          <div className="relative -top-5 mx-2">
            <button
              onClick={() => setShowQuickAddMenu(!showQuickAddMenu)}
              title="Add New Transaction"
              className={`w-14 h-14 rounded-2xl bg-[#4F46E5] hover:bg-[#4338CA] text-white flex items-center justify-center shadow-lg shadow-indigo-200 dark:shadow-none hover:scale-105 active:scale-95 transition transform border-4 border-[#F8FAFC] dark:border-[#0F172A] ${
                showQuickAddMenu ? 'rotate-45 bg-rose-500 hover:bg-rose-600 shadow-rose-200' : ''
              }`}
            >
              <Plus className="w-7 h-7 stroke-[3]" />
            </button>
          </div>

          {/* Right three tabs */}
          <div className="flex items-center justify-around flex-1 max-w-xs mx-auto md:max-w-none">
            {tabs.slice(2).map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setShowQuickAddMenu(false);
                    setActiveTab(tab.id as any);
                  }}
                  className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition ${
                    isActive
                      ? 'text-[#4F46E5] dark:text-indigo-400 font-bold scale-105'
                      : 'text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-slate-200 font-semibold'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
                  <span className="text-[10px] mt-1 tracking-tight">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>
    </>
  );
};
