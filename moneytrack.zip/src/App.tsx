import React, { useState, useEffect } from 'react';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { QuickAddModal } from './components/QuickAddModal';
import { OnboardingModal } from './components/OnboardingModal';
import { AuthModal } from './components/AuthModal';
import { SearchModal } from './components/SearchModal';
import { PremiumLockModal } from './components/PremiumLockModal';
import { HomeView } from './views/HomeView';
import { TransactionsView } from './views/TransactionsView';
import { BudgetView } from './views/BudgetView';
import { ReportsView } from './views/ReportsView';
import { ProfileView } from './views/ProfileView';
import { TransactionType } from './types';
import { Bell, X, CheckCircle, AlertCircle, Sparkles } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { userProfile, isPremiumLockOpen, lockedFeature, closePremiumLock } = useFinance();

  const [activeTab, setActiveTab] = useState<'home' | 'transactions' | 'budget' | 'reports' | 'profile'>('home');

  // Modals state
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [quickAddType, setQuickAddType] = useState<TransactionType>('expense');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [selectedTxId, setSelectedTxId] = useState<string | null>(null);

  // Apply dark mode theme class to document body
  useEffect(() => {
    if (userProfile.isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [userProfile.isDarkMode]);

  const handleOpenQuickAdd = (type: TransactionType = 'expense') => {
    setQuickAddType(type);
    setIsQuickAddOpen(true);
  };

  const handleSelectTransactionFromSearch = (id: string) => {
    setSelectedTxId(id);
    setActiveTab('transactions');
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#0F172A] text-[#1E293B] dark:text-slate-100 font-sans selection:bg-indigo-500 selection:text-white transition-colors duration-200">
      {/* Centered responsive container */}
      <div className="max-w-7xl mx-auto min-h-screen flex flex-col relative bg-[#F8FAFC] dark:bg-[#0F172A]">
        {/* Header */}
        <Header
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onOpenAuth={() => setIsAuthOpen(true)}
        />

        {/* Main View Area */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6">
          {activeTab === 'home' && (
            <HomeView
              onOpenQuickAdd={handleOpenQuickAdd}
              onNavigateToTab={(tab) => setActiveTab(tab)}
              onSelectTransaction={handleSelectTransactionFromSearch}
            />
          )}

          {activeTab === 'transactions' && (
            <TransactionsView
              onOpenQuickAdd={handleOpenQuickAdd}
              selectedTransactionId={selectedTxId}
              onClearSelectedTransaction={() => setSelectedTxId(null)}
            />
          )}

          {activeTab === 'budget' && <BudgetView onOpenQuickAdd={() => handleOpenQuickAdd('expense')} />}

          {activeTab === 'reports' && <ReportsView />}

          {activeTab === 'profile' && <ProfileView onOpenAuth={() => setIsAuthOpen(true)} />}
        </main>

        {/* Bottom Navigation */}
        <Navigation
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onOpenQuickAdd={handleOpenQuickAdd}
        />

        {/* Quick Add Transaction Modal */}
        <QuickAddModal
          isOpen={isQuickAddOpen}
          onClose={() => setIsQuickAddOpen(false)}
          initialType={quickAddType}
        />

        {/* Search Modal */}
        <SearchModal
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
          onSelectTransaction={handleSelectTransactionFromSearch}
        />

        {/* Auth Modal */}
        <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />

        {/* Premium Feature Lock Modal */}
        <PremiumLockModal
          isOpen={isPremiumLockOpen}
          feature={lockedFeature}
          onClose={closePremiumLock}
          onUpgrade={() => {
            closePremiumLock();
            setActiveTab('profile');
          }}
        />

        {/* First-time Onboarding Wizard Modal */}
        <OnboardingModal
          isOpen={!userProfile.hasCompletedOnboarding}
          onComplete={() => {}}
        />

        {/* Notifications / Reminders Sheet */}
        {isNotificationsOpen && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-start justify-center p-4 pt-16">
            <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl shadow-2xl p-5 text-[#0F172A] dark:text-slate-100 space-y-3 animate-slideDown relative">
              <button
                onClick={() => setIsNotificationsOpen(false)}
                className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full bg-slate-100 dark:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-emerald-500" />
                <h3 className="font-extrabold text-base text-[#0F172A] dark:text-white">Notifications & Alerts</h3>
              </div>

              <div className="space-y-2 pt-2">
                <div className="p-3 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-xs text-[#0F172A] dark:text-slate-200">Weekly Savings Target Achieved</p>
                    <p className="text-[11px] text-[#64748B] dark:text-slate-400">You saved {userProfile.currency.symbol}1,200 this week!</p>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-xs text-[#0F172A] dark:text-slate-200">Food Category Budget Alert</p>
                    <p className="text-[11px] text-[#64748B] dark:text-slate-400">You have used 85% of your monthly Food budget limit.</p>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-[#4F46E5] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-xs text-[#0F172A] dark:text-slate-200">Recurring Bill Reminder</p>
                    <p className="text-[11px] text-[#64748B] dark:text-slate-400">House rent payment due on 1st of next month.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <FinanceProvider>
      <MainAppContent />
    </FinanceProvider>
  );
}
