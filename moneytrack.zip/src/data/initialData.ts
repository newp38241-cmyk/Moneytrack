import { Account, Category, CategoryBudget, RecurringTransaction, SavingsGoal, Transaction, UserProfile } from '../types';

export const SUPPORTED_CURRENCIES = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'AED', symbol: 'AED', name: 'UAE Dirham' },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar' },
];

export const DEFAULT_EXPENSE_CATEGORIES: Category[] = [
  { id: 'cat-food', name: 'Food', type: 'expense', icon: 'Utensils', color: '#f97316' },
  { id: 'cat-shopping', name: 'Shopping', type: 'expense', icon: 'ShoppingBag', color: '#ec4899' },
  { id: 'cat-transport', name: 'Transport', type: 'expense', icon: 'Car', color: '#3b82f6' },
  { id: 'cat-bills', name: 'Bills', type: 'expense', icon: 'Receipt', color: '#ef4444' },
  { id: 'cat-education', name: 'Education', type: 'expense', icon: 'GraduationCap', color: '#8b5cf6' },
  { id: 'cat-health', name: 'Health', type: 'expense', icon: 'HeartPulse', color: '#10b981' },
  { id: 'cat-entertainment', name: 'Entertainment', type: 'expense', icon: 'Film', color: '#a855f7' },
  { id: 'cat-travel', name: 'Travel', type: 'expense', icon: 'Plane', color: '#06b6d4' },
  { id: 'cat-personal', name: 'Personal', type: 'expense', icon: 'User', color: '#64748b' },
  { id: 'cat-other-exp', name: 'Other', type: 'expense', icon: 'MoreHorizontal', color: '#94a3b8' },
];

export const DEFAULT_INCOME_CATEGORIES: Category[] = [
  { id: 'cat-salary', name: 'Salary', type: 'income', icon: 'Briefcase', color: '#10b981' },
  { id: 'cat-freelance', name: 'Freelance', type: 'income', icon: 'Laptop', color: '#06b6d4' },
  { id: 'cat-business', name: 'Business', type: 'income', icon: 'Building2', color: '#3b82f6' },
  { id: 'cat-pocket-money', name: 'Pocket Money', type: 'income', icon: 'Coins', color: '#f59e0b' },
  { id: 'cat-gift', name: 'Gift', type: 'income', icon: 'Gift', color: '#ec4899' },
  { id: 'cat-interest', name: 'Interest', type: 'income', icon: 'TrendingUp', color: '#8b5cf6' },
  { id: 'cat-other-inc', name: 'Other', type: 'income', icon: 'Sparkles', color: '#64748b' },
];

export const DEFAULT_ACCOUNTS: Account[] = [
  { id: 'acc-cash', name: 'Cash', type: 'cash', balance: 3500, icon: 'Banknote', color: '#10b981' },
  { id: 'acc-bank', name: 'Bank Account', type: 'bank', balance: 42500, icon: 'Landmark', color: '#3b82f6', accountNumber: '•••• 4821' },
  { id: 'acc-upi', name: 'UPI Wallet', type: 'upi', balance: 2800, icon: 'QrCode', color: '#8b5cf6' },
  { id: 'acc-savings', name: 'Savings Account', type: 'savings', balance: 85000, icon: 'PiggyBank', color: '#f59e0b' },
];

export const DEFAULT_USER_PROFILE: UserProfile = {
  id: 'user-default-1',
  name: 'Alex Morgan',
  email: 'alex@moneytrack.app',
  authProvider: 'email',
  plan: 'FREE',
  subscriptionStatus: 'active',
  currency: { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  language: 'English',
  isDarkMode: false,
  privacyMode: false,
  notificationsEnabled: true,
  hasCompletedOnboarding: true,
};

export const DEFAULT_BUDGETS: CategoryBudget[] = [
  { categoryId: 'cat-food', amount: 8000 },
  { categoryId: 'cat-shopping', amount: 5000 },
  { categoryId: 'cat-transport', amount: 3000 },
  { categoryId: 'cat-bills', amount: 4500 },
  { categoryId: 'cat-entertainment', amount: 2500 },
];

export const DEFAULT_SAVINGS_GOALS: SavingsGoal[] = [
  {
    id: 'goal-1',
    name: 'New Laptop',
    targetAmount: 65000,
    currentAmount: 28000,
    targetDate: '2026-12-31',
    categoryIcon: 'Laptop',
    color: '#3b82f6',
  },
  {
    id: 'goal-2',
    name: 'Emergency Fund',
    targetAmount: 100000,
    currentAmount: 62000,
    targetDate: '2026-10-15',
    categoryIcon: 'ShieldAlert',
    color: '#10b981',
  },
  {
    id: 'goal-3',
    name: 'Goa Vacation',
    targetAmount: 25000,
    currentAmount: 12500,
    targetDate: '2026-09-30',
    categoryIcon: 'Palmtree',
    color: '#f59e0b',
  },
];

export const DEFAULT_RECURRING: RecurringTransaction[] = [
  {
    id: 'rec-1',
    title: 'Monthly House Rent',
    type: 'expense',
    amount: 15000,
    categoryId: 'cat-bills',
    accountId: 'acc-bank',
    interval: 'monthly',
    nextDueDate: '2026-09-01',
    autoProcess: false,
    note: 'Rent payment via bank transfer',
  },
  {
    id: 'rec-2',
    title: 'Monthly Salary',
    type: 'income',
    amount: 65000,
    categoryId: 'cat-salary',
    accountId: 'acc-bank',
    interval: 'monthly',
    nextDueDate: '2026-09-01',
    autoProcess: true,
    note: 'Primary job salary credit',
  },
];

// Helper to generate realistic sample transactions for the current month & previous month
const getRecentDates = () => {
  const now = new Date();
  const formatDate = (daysAgo: number) => {
    const d = new Date(now);
    d.setDate(d.getDate() - daysAgo);
    return d.toISOString().split('T')[0];
  };
  return {
    today: formatDate(0),
    yesterday: formatDate(1),
    days3Ago: formatDate(3),
    days5Ago: formatDate(5),
    days8Ago: formatDate(8),
    days12Ago: formatDate(12),
    days15Ago: formatDate(15),
    days20Ago: formatDate(20),
  };
};

const dates = getRecentDates();

export const DEFAULT_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-1',
    userId: 'user-default-1',
    type: 'income',
    amount: 65000,
    categoryId: 'cat-salary',
    accountId: 'acc-bank',
    date: dates.days15Ago,
    time: '09:30',
    note: 'Monthly salary credited',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tx-2',
    userId: 'user-default-1',
    type: 'expense',
    amount: 4500,
    categoryId: 'cat-food',
    accountId: 'acc-upi',
    date: dates.today,
    time: '13:15',
    note: 'Grocery restock & organic produce',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tx-3',
    userId: 'user-default-1',
    type: 'expense',
    amount: 1200,
    categoryId: 'cat-transport',
    accountId: 'acc-upi',
    date: dates.yesterday,
    time: '18:45',
    note: 'Fuel top-up at Shell station',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tx-4',
    userId: 'user-default-1',
    type: 'expense',
    amount: 3200,
    categoryId: 'cat-shopping',
    accountId: 'acc-bank',
    date: dates.days3Ago,
    time: '16:20',
    note: 'New running shoes',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tx-5',
    userId: 'user-default-1',
    type: 'income',
    amount: 12500,
    categoryId: 'cat-freelance',
    accountId: 'acc-bank',
    date: dates.days5Ago,
    time: '11:00',
    note: 'UI Design contract payout',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tx-6',
    userId: 'user-default-1',
    type: 'expense',
    amount: 2400,
    categoryId: 'cat-bills',
    accountId: 'acc-upi',
    date: dates.days8Ago,
    time: '10:15',
    note: 'Electricity & Wifi bill',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tx-7',
    userId: 'user-default-1',
    type: 'expense',
    amount: 850,
    categoryId: 'cat-entertainment',
    accountId: 'acc-cash',
    date: dates.days12Ago,
    time: '20:30',
    note: 'Movie tickets & snacks',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'tx-8',
    userId: 'user-default-1',
    type: 'transfer',
    amount: 5000,
    categoryId: 'cat-other-exp',
    accountId: 'acc-bank',
    toAccountId: 'acc-savings',
    date: dates.days15Ago,
    time: '14:00',
    note: 'Transfer to Savings Goal',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];
