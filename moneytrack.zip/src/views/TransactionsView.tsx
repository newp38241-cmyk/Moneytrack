import React, { useState } from 'react';
import {
  Search,
  Filter,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  Trash2,
  Edit,
  X,
  Calendar,
  CreditCard,
  Tag,
  Paperclip,
  Check,
  AlertCircle,
  FileSpreadsheet,
} from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency, formatDateDisplay, exportTransactionsToCSV } from '../utils/formatters';
import { CategoryIcon } from '../components/CategoryIcon';
import { TimePeriod, Transaction, TransactionType } from '../types';

interface TransactionsViewProps {
  onOpenQuickAdd: (type?: TransactionType) => void;
  selectedTransactionId?: string | null;
  onClearSelectedTransaction?: () => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  onOpenQuickAdd,
  selectedTransactionId,
  onClearSelectedTransaction,
}) => {
  const {
    getFilteredTransactions,
    categories,
    accounts,
    userProfile,
    updateTransaction,
    deleteTransaction,
    timePeriod,
    setTimePeriod,
    customDateRange,
    setCustomDateRange,
  } = useFinance();

  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [accountFilter, setAccountFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest' | 'lowest'>('newest');

  // Selected Transaction for Detail / Edit Modal
  const [activeTx, setActiveTx] = useState<Transaction | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editAmount, setEditAmount] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editAccount, setEditAccount] = useState('');
  const [editNote, setEditNote] = useState('');
  const [editDate, setEditDate] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Sync external selection if passed
  React.useEffect(() => {
    if (selectedTransactionId) {
      const allTxs = getFilteredTransactions('this_year');
      const found = allTxs.find((t) => t.id === selectedTransactionId);
      if (found) {
        setActiveTx(found);
      }
    }
  }, [selectedTransactionId]);

  // Fetch filtered items
  let txList = getFilteredTransactions(
    timePeriod,
    customDateRange,
    typeFilter,
    categoryFilter,
    accountFilter,
    searchQuery
  );

  // Apply sorting
  txList = [...txList].sort((a, b) => {
    if (sortBy === 'newest') return new Date(b.date + 'T' + (b.time || '00:00')).getTime() - new Date(a.date + 'T' + (a.time || '00:00')).getTime();
    if (sortBy === 'oldest') return new Date(a.date + 'T' + (a.time || '00:00')).getTime() - new Date(b.date + 'T' + (b.time || '00:00')).getTime();
    if (sortBy === 'highest') return b.amount - a.amount;
    if (sortBy === 'lowest') return a.amount - b.amount;
    return 0;
  });

  const handleOpenDetail = (tx: Transaction) => {
    setActiveTx(tx);
    setIsEditing(false);
    setEditAmount(tx.amount.toString());
    setEditCategory(tx.categoryId);
    setEditAccount(tx.accountId);
    setEditNote(tx.note || '');
    setEditDate(tx.date);
  };

  const handleSaveEdit = () => {
    if (!activeTx) return;
    const parsedAmount = parseFloat(editAmount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) return;

    updateTransaction(activeTx.id, {
      amount: parsedAmount,
      categoryId: editCategory,
      accountId: editAccount,
      note: editNote,
      date: editDate,
    });

    setIsEditing(false);
    setActiveTx(null);
    if (onClearSelectedTransaction) onClearSelectedTransaction();
  };

  const handleDelete = (id: string) => {
    deleteTransaction(id);
    setConfirmDeleteId(null);
    setActiveTx(null);
    if (onClearSelectedTransaction) onClearSelectedTransaction();
  };

  return (
    <div className="space-y-4 pb-28 animate-fadeIn">
      {/* Search & Export Header Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-[#E2E8F0] dark:border-slate-800 p-4 shadow-xs flex items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#64748B] dark:text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search notes, category, account..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-2xl py-2.5 pl-10 pr-3 text-xs text-[#0F172A] dark:text-slate-100 focus:border-[#4F46E5] focus:outline-none placeholder-[#94A3B8] font-medium"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-slate-400 hover:text-[#0F172A] dark:hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <button
          onClick={() => exportTransactionsToCSV(txList, categories, accounts, userProfile.currency.symbol)}
          title="Export CSV"
          className="px-4 py-2.5 bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-100 dark:border-indigo-900 text-[#4F46E5] dark:text-indigo-400 rounded-2xl flex items-center gap-1.5 text-xs font-semibold shrink-0 hover:bg-indigo-100 transition"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span className="hidden sm:inline">Export CSV</span>
        </button>
      </div>

      {/* Filter Row 1: Period & Sort */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 scrollbar-none">
        <div className="flex items-center gap-1.5 shrink-0">
          {[
            { id: 'this_week', label: 'This Week' },
            { id: 'this_month', label: 'This Month' },
            { id: 'last_month', label: 'Last Month' },
            { id: 'last_3_months', label: '3 Months' },
            { id: 'this_year', label: 'This Year' },
          ].map((p) => (
            <button
              key={p.id}
              onClick={() => setTimePeriod(p.id as TimePeriod)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition ${
                timePeriod === p.id
                  ? 'bg-[#4F46E5] text-white shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-[#64748B] dark:text-slate-400 border border-[#E2E8F0] dark:border-slate-800 hover:text-[#0F172A] dark:hover:text-slate-200'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        <select
          value={sortBy}
          onChange={(e: any) => setSortBy(e.target.value)}
          className="bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 text-[#0F172A] dark:text-slate-300 text-xs font-semibold rounded-xl px-3 py-2 focus:border-[#4F46E5] focus:outline-none shrink-0"
        >
          <option value="newest">Sort: Newest</option>
          <option value="oldest">Sort: Oldest</option>
          <option value="highest">Sort: Highest</option>
          <option value="lowest">Sort: Lowest</option>
        </select>
      </div>

      {/* Filter Row 2: Type, Category, Account */}
      <div className="grid grid-cols-3 gap-2">
        {/* Type Filter */}
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 text-[#0F172A] dark:text-slate-300 text-xs font-semibold rounded-xl p-2.5 focus:border-[#4F46E5] focus:outline-none"
        >
          <option value="all">All Types</option>
          <option value="expense">Expenses</option>
          <option value="income">Income</option>
          <option value="transfer">Transfers</option>
        </select>

        {/* Category Filter */}
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 text-[#0F172A] dark:text-slate-300 text-xs font-semibold rounded-xl p-2.5 focus:border-[#4F46E5] focus:outline-none"
        >
          <option value="all">All Categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>

        {/* Account Filter */}
        <select
          value={accountFilter}
          onChange={(e) => setAccountFilter(e.target.value)}
          className="bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 text-[#0F172A] dark:text-slate-300 text-xs font-semibold rounded-xl p-2.5 focus:border-[#4F46E5] focus:outline-none"
        >
          <option value="all">All Accounts</option>
          {accounts.map((a) => (
            <option key={a.id} value={a.id}>
              {a.name}
            </option>
          ))}
        </select>
      </div>

      {/* Transactions Count & Total summary */}
      <div className="flex items-center justify-between text-xs text-[#64748B] dark:text-slate-400 px-2 pt-1 font-semibold">
        <span>Showing {txList.length} transactions</span>
        <span>
          Net:{' '}
          <strong className="text-[#0F172A] dark:text-slate-100 font-extrabold">
            {formatCurrency(
              txList.reduce((acc, t) => (t.type === 'income' ? acc + t.amount : t.type === 'expense' ? acc - t.amount : acc), 0),
              userProfile.currency.code,
              userProfile.currency.symbol,
              userProfile.privacyMode
            )}
          </strong>
        </span>
      </div>

      {/* Transactions List */}
      {txList.length === 0 ? (
        <div className="p-10 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 text-center space-y-3">
          <Filter className="w-8 h-8 text-[#94A3B8] dark:text-slate-600 mx-auto" />
          <p className="font-bold text-[#0F172A] dark:text-slate-300 text-sm">No transactions found</p>
          <p className="text-xs text-[#64748B] dark:text-slate-400 max-w-xs mx-auto">
            Try adjusting your search query, date filter, or category filter settings.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {txList.map((tx) => {
            const category = categories.find((c) => c.id === tx.categoryId);
            const account = accounts.find((a) => a.id === tx.accountId);
            const toAccount = tx.toAccountId ? accounts.find((a) => a.id === tx.toAccountId) : null;

            return (
              <div
                key={tx.id}
                onClick={() => handleOpenDetail(tx)}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800/80 hover:border-[#4F46E5] flex items-center justify-between cursor-pointer transition shadow-xs"
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-xs"
                    style={{
                      backgroundColor: category ? `${category.color}15` : '#f1f5f9',
                      color: category ? category.color : '#64748b',
                    }}
                  >
                    <CategoryIcon name={category?.icon || 'Tag'} size={20} />
                  </div>

                  <div>
                    <p className="font-bold text-xs text-[#0F172A] dark:text-slate-100 flex items-center gap-1.5">
                      <span>{tx.type === 'transfer' ? 'Transfer' : category?.name || 'Category'}</span>
                      {tx.note && <span className="text-[#64748B] dark:text-slate-400 font-normal text-[11px] truncate max-w-[120px] sm:max-w-[220px]">• {tx.note}</span>}
                    </p>
                    <p className="text-[10px] text-[#64748B] dark:text-slate-400 flex items-center gap-1.5 mt-0.5">
                      <span>
                        {account?.name || 'Account'}
                        {toAccount ? ` → ${toAccount.name}` : ''}
                      </span>
                      <span>•</span>
                      <span>{formatDateDisplay(tx.date)}</span>
                      {tx.time && <span>{tx.time}</span>}
                      {tx.attachmentUrl && <Paperclip className="w-3 h-3 text-[#4F46E5] ml-1" />}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <p
                    className={`font-black text-sm ${
                      tx.type === 'income'
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : tx.type === 'expense'
                        ? 'text-rose-600 dark:text-rose-400'
                        : 'text-indigo-600 dark:text-indigo-400'
                    }`}
                  >
                    {tx.type === 'income' ? '+' : tx.type === 'expense' ? '-' : '↔ '}
                    {formatCurrency(tx.amount, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Transaction Detail / Edit Modal */}
      {activeTx && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-slate-100 space-y-4 animate-scaleUp relative">
            <button
              onClick={() => {
                setActiveTx(null);
                if (onClearSelectedTransaction) onClearSelectedTransaction();
              }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-1">
              <span
                className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full ${
                  activeTx.type === 'income'
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : activeTx.type === 'expense'
                    ? 'bg-rose-500/20 text-rose-400'
                    : 'bg-indigo-500/20 text-indigo-400'
                }`}
              >
                {activeTx.type}
              </span>
              <h3 className="text-2xl font-black text-white">
                {formatCurrency(activeTx.amount, userProfile.currency.code, userProfile.currency.symbol)}
              </h3>
            </div>

            {isEditing ? (
              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Amount</label>
                  <input
                    type="number"
                    value={editAmount}
                    onChange={(e) => setEditAmount(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Category</label>
                  <select
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Account</label>
                  <select
                    value={editAccount}
                    onChange={(e) => setEditAccount(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
                  >
                    {accounts.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Note</label>
                  <input
                    type="text"
                    value={editNote}
                    onChange={(e) => setEditNote(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Date</label>
                  <input
                    type="date"
                    value={editDate}
                    onChange={(e) => setEditDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={handleSaveEdit}
                    className="flex-1 py-2.5 rounded-xl font-bold text-xs bg-emerald-500 text-white flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-4 h-4" /> Save
                  </button>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="py-2.5 px-4 rounded-xl font-bold text-xs bg-slate-800 text-slate-300"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3 pt-2 text-xs">
                <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Date & Time</span>
                    <span className="font-semibold text-slate-200">
                      {formatDateDisplay(activeTx.date)} {activeTx.time && `at ${activeTx.time}`}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Category</span>
                    <span className="font-semibold text-slate-200">
                      {categories.find((c) => c.id === activeTx.categoryId)?.name || 'N/A'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Account</span>
                    <span className="font-semibold text-slate-200">
                      {accounts.find((a) => a.id === activeTx.accountId)?.name || 'N/A'}
                    </span>
                  </div>
                  {activeTx.note && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Note</span>
                      <span className="font-semibold text-slate-200 text-right max-w-[180px]">{activeTx.note}</span>
                    </div>
                  )}
                </div>

                {activeTx.attachmentUrl && (
                  <div>
                    <p className="text-slate-400 text-[11px] font-bold mb-1">Attached Receipt:</p>
                    <div className="rounded-xl overflow-hidden border border-slate-800 max-h-48">
                      <img src={activeTx.attachmentUrl} alt="Receipt" className="w-full h-full object-cover" />
                    </div>
                  </div>
                )}

                {/* Delete Confirmation or Buttons */}
                {confirmDeleteId === activeTx.id ? (
                  <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-center space-y-2">
                    <p className="text-rose-400 font-bold text-xs">Delete this transaction permanently?</p>
                    <div className="flex justify-center gap-2">
                      <button
                        onClick={() => handleDelete(activeTx.id)}
                        className="px-3 py-1.5 rounded-lg bg-rose-500 text-white font-bold text-xs"
                      >
                        Yes, Delete
                      </button>
                      <button
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 font-bold text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={() => setIsEditing(true)}
                      className="flex-1 py-2.5 rounded-xl font-bold text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center gap-1.5 transition"
                    >
                      <Edit className="w-4 h-4 text-emerald-400" /> Edit
                    </button>
                    <button
                      onClick={() => setConfirmDeleteId(activeTx.id)}
                      className="py-2.5 px-4 rounded-xl font-bold text-xs bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/30 flex items-center justify-center gap-1.5 transition"
                    >
                      <Trash2 className="w-4 h-4" /> Delete
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
