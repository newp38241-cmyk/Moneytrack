import React, { useState } from 'react';
import {
  Crown,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  Zap,
  Star,
  ArrowRight,
  X,
  CreditCard,
  Smartphone,
  Info,
  Check,
} from 'lucide-react';
import { useFinance } from '../context/FinanceContext';

interface PremiumViewProps {
  onClose?: () => void;
}

export const PremiumView: React.FC<PremiumViewProps> = ({ onClose }) => {
  const { userProfile, updateUserProfile } = useFinance();
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'annual' | 'lifetime'>('annual');
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [devTestModeEnabled, setDevTestModeEnabled] = useState(false);

  const isAlreadyPremium = userProfile.plan === 'PREMIUM';

  const handleUpgrade = (planType: string) => {
    setIsProcessing(true);
    setSuccessMessage('');

    // Simulate purchase verification architecture
    setTimeout(() => {
      const mockPurchaseId = `gplay_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
      updateUserProfile({
        plan: 'PREMIUM',
        subscriptionStatus: 'active',
      });
      setIsProcessing(false);
      setSuccessMessage(`Premium activated via Test Verification (ID: ${mockPurchaseId}). Welcome to MoneyTrack Premium!`);
    }, 1200);
  };

  const handleDowngradeToFree = () => {
    updateUserProfile({
      plan: 'FREE',
      subscriptionStatus: 'active',
    });
    setSuccessMessage('Plan updated to Free Plan.');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 animate-fadeIn">
      {/* Top Banner / Header Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 p-6 sm:p-8 text-white shadow-xl">
        {/* Decorative blur elements */}
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-8 w-64 h-64 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        {onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        <div className="relative z-10 max-w-xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Crown className="w-4 h-4 text-amber-400 fill-amber-400/30" /> MoneyTrack Premium
          </div>

          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
            Take complete control of your money.
          </h1>

          <p className="text-sm text-slate-300 leading-relaxed">
            Unlock advanced analytics, unlimited accounts, budget limits, savings goals, and CSV exports to accelerate your financial freedom.
          </p>

          {isAlreadyPremium && (
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold text-xs mt-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Premium Active on your Account
            </div>
          )}
        </div>
      </div>

      {successMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button
            onClick={() => setSuccessMessage('')}
            className="text-emerald-700 dark:text-emerald-300 hover:underline text-[11px]"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Grid: Benefits List & Pricing Options */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Benefits Checklist Card */}
        <div className="md:col-span-5 bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-xs">
          <div className="flex items-center gap-2 pb-2 border-b border-[#E2E8F0] dark:border-slate-800">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h2 className="font-extrabold text-base text-[#0F172A] dark:text-white">Premium Benefits</h2>
          </div>

          <ul className="space-y-3">
            {[
              { title: 'Unlimited accounts', desc: 'Bank, cash, cards, wallets & savings' },
              { title: 'Advanced reports', desc: 'Deep financial trends & comparisons' },
              { title: 'Unlimited budgets', desc: 'Set target spending limits per category' },
              { title: 'Unlimited savings goals', desc: 'Track all emergency & purchase funds' },
              { title: 'Advanced analytics', desc: 'Monthly & yearly spending breakdown' },
              { title: 'CSV export', desc: 'Download transactions in spreadsheet format' },
              { title: 'Backup & restore', desc: 'Cloud data export & multi-device sync' },
              { title: 'Advanced reminders', desc: 'Custom alerts before bill due dates' },
              { title: 'Premium customization', desc: 'Exclusive dark themes & privacy controls' },
            ].map((benefit, idx) => (
              <li key={idx} className="flex items-start gap-3 text-xs">
                <div className="w-5 h-5 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-100 dark:border-emerald-900">
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
                <div>
                  <p className="font-bold text-[#0F172A] dark:text-slate-100">{benefit.title}</p>
                  <p className="text-[11px] text-[#64748B] dark:text-slate-400">{benefit.desc}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Pricing & Subscription Selection Card */}
        <div className="md:col-span-7 bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl p-6 space-y-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0] dark:border-slate-800">
              <h2 className="font-extrabold text-base text-[#0F172A] dark:text-white">Choose Your Plan</h2>
              <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 px-2.5 py-1 rounded-full border border-indigo-100 dark:border-indigo-900">
                Google Play Billing Ready
              </span>
            </div>

            {/* Plans List */}
            <div className="space-y-3 mt-4">
              {/* Annual Plan */}
              <div
                onClick={() => setSelectedPlan('annual')}
                className={`p-4 rounded-2xl border-2 transition cursor-pointer relative ${
                  selectedPlan === 'annual'
                    ? 'bg-indigo-50/50 dark:bg-indigo-950/30 border-[#4F46E5] shadow-xs'
                    : 'bg-white dark:bg-slate-950 border-[#E2E8F0] dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <div className="absolute -top-3 right-4 bg-gradient-to-r from-amber-500 to-indigo-600 text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full shadow-xs flex items-center gap-1">
                  <Star className="w-3 h-3 fill-white" /> Save 44% • Best Value
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-sm text-[#0F172A] dark:text-white">Annual Subscription</h3>
                    <p className="text-xs text-[#64748B] dark:text-slate-400">Billed yearly • Includes 7-day free trial</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-[#4F46E5] dark:text-indigo-400">$19.99</p>
                    <p className="text-[10px] text-[#64748B] dark:text-slate-400">$1.66 / month</p>
                  </div>
                </div>
              </div>

              {/* Monthly Plan */}
              <div
                onClick={() => setSelectedPlan('monthly')}
                className={`p-4 rounded-2xl border-2 transition cursor-pointer ${
                  selectedPlan === 'monthly'
                    ? 'bg-indigo-50/50 dark:bg-indigo-950/30 border-[#4F46E5] shadow-xs'
                    : 'bg-white dark:bg-slate-950 border-[#E2E8F0] dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-sm text-[#0F172A] dark:text-white">Monthly Subscription</h3>
                    <p className="text-xs text-[#64748B] dark:text-slate-400">Flexibility to cancel anytime</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-[#0F172A] dark:text-white">$2.99</p>
                    <p className="text-[10px] text-[#64748B] dark:text-slate-400">per month</p>
                  </div>
                </div>
              </div>

              {/* Lifetime Plan */}
              <div
                onClick={() => setSelectedPlan('lifetime')}
                className={`p-4 rounded-2xl border-2 transition cursor-pointer ${
                  selectedPlan === 'lifetime'
                    ? 'bg-indigo-50/50 dark:bg-indigo-950/30 border-[#4F46E5] shadow-xs'
                    : 'bg-white dark:bg-slate-950 border-[#E2E8F0] dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-sm text-[#0F172A] dark:text-white">Lifetime Access</h3>
                    <p className="text-xs text-[#64748B] dark:text-slate-400">One-time payment • Pay once, use forever</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-black text-[#0F172A] dark:text-white">$49.99</p>
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">One-time</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Checkout / Upgrade CTA */}
          <div className="space-y-3 pt-2">
            {!isAlreadyPremium ? (
              <button
                onClick={() => handleUpgrade(selectedPlan)}
                disabled={isProcessing}
                className="w-full py-4 px-6 rounded-2xl font-black text-sm bg-gradient-to-r from-amber-500 via-indigo-600 to-indigo-700 hover:opacity-95 text-white shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 transition active:scale-[0.99] disabled:opacity-50"
              >
                {isProcessing ? (
                  <span className="flex items-center gap-2">
                    <Zap className="w-4 h-4 animate-spin" />
                    Connecting to Payment Gateway...
                  </span>
                ) : (
                  <>
                    <Crown className="w-5 h-5 text-amber-300" />
                    <span>Subscribe to Premium ({selectedPlan.toUpperCase()})</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            ) : (
              <div className="space-y-2">
                <button
                  disabled
                  className="w-full py-3.5 px-4 rounded-2xl font-bold text-sm bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  <span>Your Premium Subscription is Active</span>
                </button>
                <button
                  onClick={handleDowngradeToFree}
                  className="w-full py-2 text-xs font-semibold text-[#64748B] hover:text-rose-600 transition"
                >
                  Switch back to Free Plan
                </button>
              </div>
            )}

            <div className="p-3 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 text-[11px] text-[#64748B] dark:text-slate-400 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-[#0F172A] dark:text-slate-200">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Production Android & Web Architecture</span>
              </div>
              <p>
                In the Android production build, subscriptions will automatically integrate with Google Play Billing. No payment card details are stored locally.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
