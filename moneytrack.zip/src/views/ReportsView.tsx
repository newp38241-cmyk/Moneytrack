import React, { useState } from 'react';
import { BarChart3, TrendingUp, TrendingDown, PieChart, Calendar, Award, DollarSign, Wallet } from 'lucide-react';
import { ResponsiveContainer, PieChart as RePieChart, Pie, Cell, BarChart as ReBarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, AreaChart, Area } from 'recharts';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency } from '../utils/formatters';
import { CategoryIcon } from '../components/CategoryIcon';
import { TimePeriod } from '../types';

export const ReportsView: React.FC = () => {
  const {
    getFilteredTransactions,
    categories,
    timePeriod,
    setTimePeriod,
    customDateRange,
    setCustomDateRange,
    userProfile,
  } = useFinance();

  const [activeChart, setActiveChart] = useState<'categories' | 'trend' | 'incomeVsExpense'>('categories');

  const filteredTxs = getFilteredTransactions(timePeriod, customDateRange);

  // Compute stats
  const totalIncome = filteredTxs.filter((t) => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = filteredTxs.filter((t) => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const netSavings = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? (netSavings / totalIncome) * 100 : 0;

  // Category breakdown for pie chart
  const categoryMap = new Map<string, number>();
  filteredTxs
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      const current = categoryMap.get(t.categoryId) || 0;
      categoryMap.set(t.categoryId, current + t.amount);
    });

  const pieChartData = Array.from(categoryMap.entries()).map(([catId, amount]) => {
    const category = categories.find((c) => c.id === catId);
    return {
      name: category?.name || 'Other',
      value: amount,
      color: category?.color || '#3b82f6',
      icon: category?.icon || 'Tag',
    };
  }).sort((a, b) => b.value - a.value);

  const highestCategory = pieChartData.length > 0 ? pieChartData[0] : null;

  // Daily spending trend data
  const dateMap = new Map<string, { date: string; income: number; expense: number }>();
  filteredTxs.forEach((t) => {
    const existing = dateMap.get(t.date) || { date: t.date.slice(5), income: 0, expense: 0 };
    if (t.type === 'income') existing.income += t.amount;
    if (t.type === 'expense') existing.expense += t.amount;
    dateMap.set(t.date, existing);
  });

  const trendData = Array.from(dateMap.values()).sort((a, b) => a.date.localeCompare(b.date));

  // Income vs Expense comparative data
  const comparisonData = [
    { name: 'Income', amount: totalIncome, fill: '#10b981' },
    { name: 'Expense', amount: totalExpense, fill: '#f43f5e' },
    { name: 'Savings', amount: Math.max(0, netSavings), fill: '#06b6d4' },
  ];

  return (
    <div className="space-y-5 pb-28 animate-fadeIn">
      {/* Period Filter Selector Card */}
      <div className="p-2 bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl shadow-xs flex items-center justify-between overflow-x-auto gap-1">
        {[
          { id: 'this_week', label: 'This Week' },
          { id: 'this_month', label: 'This Month' },
          { id: 'last_month', label: 'Last Month' },
          { id: 'last_3_months', label: '3 Months' },
          { id: 'this_year', label: 'This Year' },
        ].map((p) => (
          <button
            key={p.id}
            onClick={() => setTimePeriod(p.id as TimePeriod)}
            className={`px-3.5 py-2 rounded-2xl text-xs font-semibold whitespace-nowrap transition ${
              timePeriod === p.id
                ? 'bg-[#4F46E5] text-white shadow-sm'
                : 'text-[#64748B] dark:text-slate-400 hover:text-[#0F172A] dark:hover:text-slate-200'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Analytics Summary Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-1">
          <p className="text-[10px] font-bold text-[#64748B] dark:text-slate-400 uppercase tracking-wider">Total Income</p>
          <p className="text-base font-extrabold text-emerald-600 dark:text-emerald-400">
            {formatCurrency(totalIncome, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
          </p>
          <p className="text-[10px] text-[#94A3B8] dark:text-slate-500">Inflow in selected period</p>
        </div>

        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-1">
          <p className="text-[10px] font-bold text-[#64748B] dark:text-slate-400 uppercase tracking-wider">Total Expense</p>
          <p className="text-base font-extrabold text-rose-600 dark:text-rose-400">
            {formatCurrency(totalExpense, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
          </p>
          <p className="text-[10px] text-[#94A3B8] dark:text-slate-500">Outflow in selected period</p>
        </div>

        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-1">
          <p className="text-[10px] font-bold text-[#64748B] dark:text-slate-400 uppercase tracking-wider">Net Savings</p>
          <p className="text-base font-extrabold text-teal-600 dark:text-teal-400">
            {formatCurrency(netSavings, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
          </p>
          <p className="text-[10px] text-[#94A3B8] dark:text-slate-500">Income minus Expense</p>
        </div>

        <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-1">
          <p className="text-[10px] font-bold text-[#64748B] dark:text-slate-400 uppercase tracking-wider">Savings Rate</p>
          <p className="text-base font-extrabold text-[#4F46E5] dark:text-indigo-400">{savingsRate.toFixed(1)}%</p>
          <p className="text-[10px] text-[#94A3B8] dark:text-slate-500">Target &gt; 20%</p>
        </div>
      </div>

      {/* Highest Spending Category Card */}
      {highestCategory && (
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-[#4F46E5] dark:text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-100 dark:border-indigo-900">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-[#4F46E5] dark:text-indigo-400">Highest Spending Category</p>
              <p className="font-extrabold text-sm text-[#0F172A] dark:text-white">{highestCategory.name}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-black text-sm text-rose-600 dark:text-rose-400">
              {formatCurrency(highestCategory.value, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
            </p>
            <p className="text-[10px] text-[#64748B] dark:text-slate-400 font-medium">
              {totalExpense > 0 ? ((highestCategory.value / totalExpense) * 100).toFixed(0) : 0}% of total
            </p>
          </div>
        </div>
      )}

      {/* Chart View Switcher Card */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#E2E8F0] dark:border-slate-800/80 pb-3">
          <h3 className="font-bold text-sm text-[#0F172A] dark:text-white flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" /> Visual Analytics
          </h3>

          <div className="flex gap-1 bg-[#F1F5F9] dark:bg-slate-950 p-1 rounded-xl">
            <button
              onClick={() => setActiveChart('categories')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                activeChart === 'categories' ? 'bg-white dark:bg-slate-800 text-[#0F172A] dark:text-white shadow-xs' : 'text-[#64748B] dark:text-slate-400'
              }`}
            >
              Categories
            </button>
            <button
              onClick={() => setActiveChart('trend')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                activeChart === 'trend' ? 'bg-white dark:bg-slate-800 text-[#0F172A] dark:text-white shadow-xs' : 'text-[#64748B] dark:text-slate-400'
              }`}
            >
              Trend
            </button>
            <button
              onClick={() => setActiveChart('incomeVsExpense')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                activeChart === 'incomeVsExpense' ? 'bg-white dark:bg-slate-800 text-[#0F172A] dark:text-white shadow-xs' : 'text-[#64748B] dark:text-slate-400'
              }`}
            >
              Income vs Expense
            </button>
          </div>
        </div>

        {/* Category Donut Chart */}
        {activeChart === 'categories' && (
          <div className="space-y-4">
            {pieChartData.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                No expense data recorded in this period.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                <div className="h-56 w-full flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={pieChartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={55}
                        outerRadius={80}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {pieChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(val: number) =>
                          formatCurrency(val, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)
                        }
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                      />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>

                {/* Category Legend List */}
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {pieChartData.map((item) => (
                    <div key={item.name} className="flex items-center justify-between text-xs p-2 rounded-xl bg-slate-950/40 border border-slate-800/60">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="font-semibold text-slate-200">{item.name}</span>
                      </div>
                      <div className="text-right font-bold text-slate-200">
                        {formatCurrency(item.value, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                        <span className="text-[10px] text-slate-400 font-normal ml-1.5">
                          ({totalExpense > 0 ? ((item.value / totalExpense) * 100).toFixed(0) : 0}%)
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Daily Spending Trend Chart */}
        {activeChart === 'trend' && (
          <div className="h-64 w-full pt-2">
            {trendData.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">No activity in this period.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData}>
                  <defs>
                    <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={10} />
                  <YAxis stroke="#64748b" fontSize={10} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }} />
                  <Area type="monotone" dataKey="expense" stroke="#f43f5e" fillOpacity={1} fill="url(#colorExpense)" name="Expense" />
                  <Area type="monotone" dataKey="income" stroke="#10b981" fillOpacity={1} fill="url(#colorIncome)" name="Income" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        )}

        {/* Income vs Expense Bar Chart */}
        {activeChart === 'incomeVsExpense' && (
          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <ReBarChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip
                  formatter={(val: number) =>
                    formatCurrency(val, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)
                  }
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                />
                <Bar dataKey="amount" radius={[8, 8, 0, 0]}>
                  {comparisonData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </ReBarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
};
