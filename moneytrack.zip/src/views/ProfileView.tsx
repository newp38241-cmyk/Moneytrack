import React, { useState } from 'react';
import {
  User,
  DollarSign,
  Moon,
  Sun,
  Eye,
  EyeOff,
  Bell,
  CreditCard,
  Tag,
  Download,
  Upload,
  RotateCcw,
  Shield,
  Plus,
  Trash2,
  Check,
  X,
  FileSpreadsheet,
  LogOut,
  Sparkles,
  Crown,
  ChevronRight,
  Settings,
  ShieldAlert,
  HelpCircle,
  FolderSync,
} from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { SUPPORTED_CURRENCIES } from '../data/initialData';
import { SavingsGoalsSection } from '../components/SavingsGoalsSection';
import { RecurringSection } from '../components/RecurringSection';
import { formatCurrency, exportTransactionsToCSV } from '../utils/formatters';
import { CategoryIcon } from '../components/CategoryIcon';
import { PremiumView } from './PremiumView';

export const ProfileView: React.FC<{ onOpenAuth: () => void }> = ({ onOpenAuth }) => {
  const {
    userProfile,
    updateUserProfile,
    accounts,
    addAccount,
    deleteAccount,
    categories,
    addCategory,
    deleteCategory,
    transactions,
    exportJSON,
    restoreFromJSON,
    resetAllData,
    isLoggedIn,
    logout,
    canAccess,
    triggerPremiumLock,
  } = useFinance();

  const [activeSubView, setActiveSubView] = useState<'main' | 'premium' | 'accounts' | 'categories' | 'backup'>('main');

  // Modals
  const [isOpenAddAccount, setIsOpenAddAccount] = useState(false);
  const [newAccName, setNewAccName] = useState('');
  const [newAccType, setNewAccType] = useState<any>('bank');
  const [newAccBal, setNewAccBal] = useState('');

  const [isOpenAddCategory, setIsOpenAddCategory] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatType, setNewCatType] = useState<'expense' | 'income'>('expense');
  const [newCatIcon, setNewCatIcon] = useState('Tag');
  const [newCatColor, setNewCatColor] = useState('#3b82f6');

  // Delete Account modal
  const [showDeleteAccountModal, setShowDeleteAccountModal] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState('');
  const [noticeMessage, setNoticeMessage] = useState('');

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const bal = parseFloat(newAccBal) || 0;
    if (!newAccName.trim()) return;

    const ok = addAccount({
      name: newAccName.trim(),
      type: newAccType,
      balance: bal,
      icon: 'CreditCard',
      color: '#3b82f6',
    });

    if (ok) {
      setIsOpenAddAccount(false);
      setNewAccName('');
      setNewAccBal('');
    }
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const ok = addCategory({
      name: newCatName.trim(),
      type: newCatType,
      icon: newCatIcon,
      color: newCatColor,
    });

    if (ok) {
      setIsOpenAddCategory(false);
      setNewCatName('');
    }
  };

  const handleJSONImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const text = evt.target?.result as string;
        if (text) {
          const ok = restoreFromJSON(text);
          if (ok) {
            setRestoreMessage('Data restored successfully!');
            setTimeout(() => setRestoreMessage(''), 3000);
          } else {
            setRestoreMessage('Invalid JSON backup file.');
          }
        }
      };
      reader.readAsText(file);
    }
  };

  const handleExportCSV = () => {
    if (!canAccess('CSV_EXPORT')) {
      triggerPremiumLock('CSV_EXPORT');
      return;
    }
    exportTransactionsToCSV(transactions, categories, accounts, userProfile.currency.symbol);
  };

  const handleDownloadJSON = () => {
    const json = exportJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MoneyTrack_Backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  if (activeSubView === 'premium') {
    return <PremiumView onClose={() => setActiveSubView('main')} />;
  }

  return (
    <div className="space-y-5 pb-28 animate-fadeIn max-w-4xl mx-auto">
      {/* 1. Profile Header Card */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 text-[#0F172A] dark:text-slate-100 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#4F46E5] via-indigo-500 to-purple-600 text-white font-black text-2xl flex items-center justify-center shadow-md shadow-indigo-500/20 shrink-0 overflow-hidden">
            {userProfile.pictureUrl ? (
              <img src={userProfile.pictureUrl} alt={userProfile.name} className="w-full h-full object-cover" />
            ) : (
              userProfile.name.charAt(0).toUpperCase()
            )}
          </div>
          <div>
            <h2 className="font-black text-lg text-[#0F172A] dark:text-white flex items-center gap-2">
              <span>{userProfile.name}</span>
              {userProfile.plan === 'PREMIUM' && (
                <Crown className="w-4 h-4 text-amber-500 fill-amber-500/30 shrink-0" />
              )}
            </h2>
            <p className="text-xs text-[#64748B] dark:text-slate-400 font-medium">{userProfile.email}</p>
            
            <div className="mt-1.5 flex items-center gap-2">
              <span className={`inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                userProfile.plan === 'PREMIUM'
                  ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-900'
                  : 'bg-indigo-50 dark:bg-indigo-950/60 text-[#4F46E5] dark:text-indigo-400 border-indigo-100 dark:border-indigo-900'
              }`}>
                {userProfile.plan === 'PREMIUM' ? (
                  <>
                    <Sparkles className="w-3 h-3 text-amber-500" /> Premium Active
                  </>
                ) : (
                  'Free Plan'
                )}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {userProfile.plan === 'FREE' && (
            <button
              onClick={() => setActiveSubView('premium')}
              className="flex-1 sm:flex-none py-2.5 px-4 rounded-2xl font-bold text-xs bg-gradient-to-r from-amber-500 to-indigo-600 hover:opacity-95 text-white shadow-xs flex items-center justify-center gap-1.5 transition"
            >
              <Crown className="w-4 h-4 text-amber-300" /> Upgrade
            </button>
          )}

          <button
            onClick={onOpenAuth}
            className="py-2.5 px-4 rounded-2xl bg-[#F1F5F9] dark:bg-slate-800 hover:bg-[#E2E8F0] dark:hover:bg-slate-700 text-[#0F172A] dark:text-slate-200 transition text-xs font-bold flex items-center justify-center gap-1.5"
          >
            {isLoggedIn ? <LogOut className="w-4 h-4 text-rose-500" /> : 'Sign In'}
            <span>{isLoggedIn ? 'Sign Out' : 'Sign In'}</span>
          </button>
        </div>
      </div>

      {noticeMessage && (
        <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-[#4F46E5] dark:text-indigo-300 text-xs font-bold flex items-center justify-between">
          <span>{noticeMessage}</span>
          <button onClick={() => setNoticeMessage('')} className="text-xs hover:underline">Dismiss</button>
        </div>
      )}

      {/* 2. Menu Action Buttons List as required in Prompt */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-1">
        <h3 className="font-bold text-xs text-[#64748B] dark:text-slate-400 uppercase tracking-wider mb-2 px-1">Account & Settings</h3>

        {/* Manage Premium */}
        <button
          onClick={() => setActiveSubView('premium')}
          className="w-full p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between transition text-left group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center border border-amber-200 dark:border-amber-900">
              <Crown className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100 flex items-center gap-1.5">
                <span>Manage Premium</span>
                {userProfile.plan === 'FREE' && (
                  <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold bg-amber-50 dark:bg-amber-950 px-2 py-0.5 rounded-md">Upgrade</span>
                )}
              </p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">View features, plans & subscription status</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#94A3B8] group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Account Settings */}
        <button
          onClick={() => onOpenAuth()}
          className="w-full p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between transition text-left group border-t border-[#F1F5F9] dark:border-slate-800/60"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-[#4F46E5] dark:text-indigo-400 flex items-center justify-center border border-indigo-100 dark:border-indigo-900">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100">Account Settings</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">Authentication profile, email & security</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#94A3B8] group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Categories */}
        <button
          onClick={() => {
            const el = document.getElementById('categories-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="w-full p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between transition text-left group border-t border-[#F1F5F9] dark:border-slate-800/60"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 flex items-center justify-center border border-purple-100 dark:border-purple-900">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100">Categories ({categories.length})</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">Manage income & expense category labels</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#94A3B8] group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Accounts */}
        <button
          onClick={() => {
            const el = document.getElementById('accounts-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="w-full p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between transition text-left group border-t border-[#F1F5F9] dark:border-slate-800/60"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-50 dark:bg-teal-950/50 text-teal-600 dark:text-teal-400 flex items-center justify-center border border-teal-100 dark:border-teal-900">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100">Accounts ({accounts.length})</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">Banks, wallets, UPI, cash & savings</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#94A3B8] group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Notifications Toggle row */}
        <div className="p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between border-t border-[#F1F5F9] dark:border-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-[#4F46E5] dark:text-indigo-400 flex items-center justify-center border border-indigo-100 dark:border-indigo-900">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100">Notifications & Alerts</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">Reminders for bills and budget limits</p>
            </div>
          </div>
          <input
            type="checkbox"
            checked={userProfile.notificationsEnabled}
            onChange={(e) => updateUserProfile({ notificationsEnabled: e.target.checked })}
            className="w-4 h-4 accent-[#4F46E5] rounded cursor-pointer"
          />
        </div>

        {/* Theme */}
        <div className="p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between border-t border-[#F1F5F9] dark:border-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center border border-amber-100 dark:border-amber-900">
              {userProfile.isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100">Theme</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">{userProfile.isDarkMode ? 'Dark Mode' : 'Light Mode'}</p>
            </div>
          </div>
          <button
            onClick={() => updateUserProfile({ isDarkMode: !userProfile.isDarkMode })}
            className="px-3 py-1 rounded-xl text-xs font-bold bg-[#F1F5F9] dark:bg-slate-800 text-[#0F172A] dark:text-slate-200 border border-[#E2E8F0] dark:border-slate-700"
          >
            {userProfile.isDarkMode ? 'Dark' : 'Light'}
          </button>
        </div>

        {/* Currency Picker */}
        <div className="p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between border-t border-[#F1F5F9] dark:border-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border border-emerald-100 dark:border-emerald-900">
              <DollarSign className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100">Currency</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">{userProfile.currency.name} ({userProfile.currency.symbol})</p>
            </div>
          </div>
          <select
            value={userProfile.currency.code}
            onChange={(e) => {
              const found = SUPPORTED_CURRENCIES.find((c) => c.code === e.target.value);
              if (found) updateUserProfile({ currency: found });
            }}
            className="bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 text-[#0F172A] dark:text-slate-200 text-xs font-bold rounded-xl p-2 focus:border-[#4F46E5] focus:outline-none"
          >
            {SUPPORTED_CURRENCIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.code} ({c.symbol})
              </option>
            ))}
          </select>
        </div>

        {/* Privacy Mode */}
        <div className="p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between border-t border-[#F1F5F9] dark:border-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center border border-slate-200 dark:border-slate-700">
              {userProfile.privacyMode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100">Privacy Mode</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">Mask balance values across app</p>
            </div>
          </div>
          <input
            type="checkbox"
            checked={userProfile.privacyMode}
            onChange={(e) => updateUserProfile({ privacyMode: e.target.checked })}
            className="w-4 h-4 accent-[#4F46E5] rounded cursor-pointer"
          />
        </div>

        {/* Export Data */}
        <button
          onClick={handleExportCSV}
          className="w-full p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between transition text-left group border-t border-[#F1F5F9] dark:border-slate-800/60"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border border-emerald-100 dark:border-emerald-900">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100 flex items-center gap-1.5">
                <span>Export Data</span>
                {userProfile.plan === 'FREE' && (
                  <Crown className="w-3.5 h-3.5 text-amber-500 fill-amber-500/20" />
                )}
              </p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">Download transaction logs in CSV spreadsheet format</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#94A3B8] group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Backup */}
        <button
          onClick={() => {
            const el = document.getElementById('backup-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="w-full p-3.5 rounded-2xl hover:bg-[#F8FAFC] dark:hover:bg-slate-950 flex items-center justify-between transition text-left group border-t border-[#F1F5F9] dark:border-slate-800/60"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-[#4F46E5] dark:text-indigo-400 flex items-center justify-center border border-indigo-100 dark:border-indigo-900">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-[#0F172A] dark:text-slate-100">Backup & Restore</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">Save complete profile JSON snapshot</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#94A3B8] group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Delete Account */}
        <button
          onClick={() => setShowDeleteAccountModal(true)}
          className="w-full p-3.5 rounded-2xl hover:bg-rose-50/50 dark:hover:bg-rose-950/30 flex items-center justify-between transition text-left group border-t border-[#F1F5F9] dark:border-slate-800/60"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center border border-rose-100 dark:border-rose-900">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <p className="font-extrabold text-xs text-rose-600 dark:text-rose-400">Delete Account</p>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400">Remove personal account data permanently</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-rose-400 group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Logout */}
        {isLoggedIn && (
          <button
            onClick={() => logout()}
            className="w-full p-3.5 rounded-2xl hover:bg-rose-50/50 dark:hover:bg-rose-950/30 flex items-center justify-between transition text-left group border-t border-[#F1F5F9] dark:border-slate-800/60"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center border border-rose-100 dark:border-rose-900">
                <LogOut className="w-4 h-4" />
              </div>
              <div>
                <p className="font-extrabold text-xs text-rose-600 dark:text-rose-400">Logout</p>
                <p className="text-[10px] text-[#64748B] dark:text-slate-400">Sign out of current account</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-rose-400 group-hover:translate-x-0.5 transition-transform" />
          </button>
        )}
      </div>

      {/* 3. Accounts Management Section */}
      <div id="accounts-section" className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" />
            <h3 className="font-bold text-xs text-[#64748B] dark:text-slate-400 uppercase tracking-wider">Your Accounts ({accounts.length})</h3>
          </div>
          <button
            onClick={() => setIsOpenAddAccount(true)}
            className="text-xs font-bold text-[#4F46E5] hover:underline flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add Account
          </button>
        </div>

        <div className="space-y-2">
          {accounts.map((acc) => (
            <div
              key={acc.id}
              className="p-3.5 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 flex items-center justify-between"
            >
              <div>
                <p className="font-bold text-xs text-[#0F172A] dark:text-slate-100 flex items-center gap-1.5">
                  <span>{acc.name}</span>
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md bg-[#E2E8F0] dark:bg-slate-800 text-[#475569] dark:text-slate-400">
                    {acc.type}
                  </span>
                </p>
                <p className="text-[10px] text-[#64748B] dark:text-slate-400 mt-0.5">{acc.accountNumber || 'Primary Wallet'}</p>
              </div>

              <div className="flex items-center gap-3">
                <span className="font-black text-xs text-emerald-600 dark:text-emerald-400">
                  {formatCurrency(acc.balance, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                </span>
                {accounts.length > 1 && (
                  <button
                    onClick={() => deleteAccount(acc.id)}
                    className="p-1 text-[#94A3B8] hover:text-rose-600 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Savings Goals & Recurring Section */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs">
        <SavingsGoalsSection />
      </div>

      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs">
        <RecurringSection />
      </div>

      {/* 5. Categories Section */}
      <div id="categories-section" className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" />
            <h3 className="font-bold text-xs text-[#64748B] dark:text-slate-400 uppercase tracking-wider">Categories ({categories.length})</h3>
          </div>
          <button
            onClick={() => setIsOpenAddCategory(true)}
            className="text-xs font-bold text-[#4F46E5] hover:underline flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add Category
          </button>
        </div>

        <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-1">
          {categories.map((c) => (
            <div
              key={c.id}
              className="px-3 py-1.5 rounded-xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 flex items-center gap-1.5 text-xs text-[#0F172A] dark:text-slate-200"
            >
              <CategoryIcon name={c.icon} size={14} color={c.color} />
              <span className="font-semibold text-[11px]">{c.name}</span>
              {c.isCustom && (
                <button onClick={() => deleteCategory(c.id)} className="text-[#94A3B8] hover:text-rose-600 ml-1">
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 6. Data Backup Section */}
      <div id="backup-section" className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="font-bold text-xs text-[#64748B] dark:text-slate-400 uppercase tracking-wider">Backup & Reset</h3>

        {restoreMessage && (
          <p className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400 text-xs text-center font-bold">
            {restoreMessage}
          </p>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <button
            onClick={handleDownloadJSON}
            className="py-2.5 px-3 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 hover:border-[#4F46E5] text-[#0F172A] dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition"
          >
            <Download className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" /> Export JSON Backup
          </button>

          <label className="cursor-pointer py-2.5 px-3 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 hover:border-[#4F46E5] text-[#0F172A] dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition">
            <Upload className="w-4 h-4 text-teal-600 dark:text-teal-400" /> Restore JSON Backup
            <input type="file" accept=".json" onChange={handleJSONImport} className="hidden" />
          </label>
        </div>

        <div className="pt-2 border-t border-[#E2E8F0] dark:border-slate-800">
          {showResetConfirm ? (
            <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 text-center space-y-2">
              <p className="text-xs font-bold text-rose-700 dark:text-rose-400">Reset all app data to fresh state?</p>
              <div className="flex justify-center gap-2">
                <button
                  onClick={() => {
                    resetAllData();
                    setShowResetConfirm(false);
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-rose-600 text-white font-bold text-xs"
                >
                  Yes, Reset Everything
                </button>
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-[#0F172A] dark:text-slate-300 font-bold text-xs border border-[#E2E8F0] dark:border-slate-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="w-full py-2.5 px-3 rounded-2xl bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/20 font-bold text-xs flex items-center justify-center gap-2 transition"
            >
              <RotateCcw className="w-4 h-4" /> Reset App Data
            </button>
          )}
        </div>
      </div>

      {/* 7. Strict Developer Branding & App Version Footer */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 shadow-xs text-center space-y-2">
        <div className="flex items-center justify-center gap-2 text-[#0F172A] dark:text-white font-black text-lg">
          <div className="w-6 h-6 bg-[#4F46E5] rounded-lg flex items-center justify-center text-white text-xs">
            M
          </div>
          <span>MoneyTrack</span>
        </div>
        <p className="text-xs text-[#64748B] dark:text-slate-400 font-medium">Version 1.0.0</p>
        <div className="pt-2 border-t border-[#F1F5F9] dark:border-slate-800">
          <p className="text-xs font-black text-[#4F46E5] dark:text-indigo-400 uppercase tracking-widest">
            Developed by ARYAN SHEIKH
          </p>
        </div>
      </div>

      {/* Modals */}
      {showDeleteAccountModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl p-6 text-center space-y-4 shadow-2xl animate-scaleUp">
            <ShieldAlert className="w-12 h-12 text-rose-500 mx-auto" />
            <div>
              <h3 className="font-extrabold text-base text-[#0F172A] dark:text-white">Delete MoneyTrack Account?</h3>
              <p className="text-xs text-[#64748B] dark:text-slate-400 mt-1">
                This action will delete your account preferences and stored financial data permanently.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  resetAllData();
                  logout();
                  setShowDeleteAccountModal(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs"
              >
                Delete Account
              </button>
              <button
                onClick={() => setShowDeleteAccountModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 text-[#0F172A] dark:text-slate-200 font-bold text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {isOpenAddAccount && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl animate-scaleUp relative">
            <button
              onClick={() => setIsOpenAddAccount(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full bg-slate-100 dark:bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-lg font-bold text-[#0F172A] dark:text-white">Add New Account</h3>
            <form onSubmit={handleCreateAccount} className="space-y-3">
              <div>
                <label className="block text-xs text-[#64748B] dark:text-slate-400 mb-1 font-semibold">Account Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. HDFC Savings, UPI Wallet"
                  value={newAccName}
                  onChange={(e) => setNewAccName(e.target.value)}
                  className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-2.5 text-xs text-[#0F172A] dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-[#64748B] dark:text-slate-400 mb-1 font-semibold">Type</label>
                <select
                  value={newAccType}
                  onChange={(e: any) => setNewAccType(e.target.value)}
                  className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-2.5 text-xs text-[#0F172A] dark:text-white"
                >
                  <option value="cash">Cash</option>
                  <option value="bank">Bank Account</option>
                  <option value="upi">UPI Wallet</option>
                  <option value="savings">Savings Account</option>
                  <option value="custom">Custom Account</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-[#64748B] dark:text-slate-400 mb-1 font-semibold">
                  Starting Balance ({userProfile.currency.symbol})
                </label>
                <input
                  type="number"
                  placeholder="0"
                  value={newAccBal}
                  onChange={(e) => setNewAccBal(e.target.value)}
                  className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-2.5 text-xs text-[#0F172A] dark:text-white font-bold"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl font-bold text-xs bg-[#4F46E5] text-white flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Check className="w-4 h-4" /> Create Account
              </button>
            </form>
          </div>
        </div>
      )}

      {isOpenAddCategory && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl animate-scaleUp relative">
            <button
              onClick={() => setIsOpenAddCategory(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full bg-slate-100 dark:bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-lg font-bold text-[#0F172A] dark:text-white">Create Custom Category</h3>
            <form onSubmit={handleCreateCategory} className="space-y-3">
              <div>
                <label className="block text-xs text-[#64748B] dark:text-slate-400 mb-1 font-semibold">Category Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Streaming, Subscriptions"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-2.5 text-xs text-[#0F172A] dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs text-[#64748B] dark:text-slate-400 mb-1 font-semibold">Type</label>
                  <select
                    value={newCatType}
                    onChange={(e: any) => setNewCatType(e.target.value)}
                    className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-2.5 text-xs text-[#0F172A] dark:text-white"
                  >
                    <option value="expense">Expense</option>
                    <option value="income">Income</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[#64748B] dark:text-slate-400 mb-1 font-semibold">Color</label>
                  <input
                    type="color"
                    value={newCatColor}
                    onChange={(e) => setNewCatColor(e.target.value)}
                    className="w-full h-9 bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-1 cursor-pointer"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl font-bold text-xs bg-[#4F46E5] text-white flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Check className="w-4 h-4" /> Save Category
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
