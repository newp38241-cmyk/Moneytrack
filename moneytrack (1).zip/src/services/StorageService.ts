import {
  Account,
  Category,
  CategoryBudget,
  RecurringTransaction,
  SavingsGoal,
  Transaction,
  UserProfile,
} from '../types';
import { platformService } from './PlatformService';

export interface SyncedDataPayload {
  categories: Category[];
  accounts: Account[];
  transactions: Transaction[];
  budgets: CategoryBudget[];
  savingsGoals: SavingsGoal[];
  recurringTransactions: RecurringTransaction[];
  userProfileUpdates?: Partial<UserProfile>;
}

export class StorageService {
  private static instance: StorageService;
  private syncQueueKey = 'moneytrack_pending_offline_sync_queue_v2';
  private localDataKey = 'moneytrack_local_cached_financials_v2';
  private pendingSyncCountCallbacks: Set<(count: number) => void> = new Set();

  private constructor() {
    platformService.onNetworkStatusChange((status) => {
      if (status.connected) {
        this.flushOfflineQueue();
      }
    });
  }

  public static getInstance(): StorageService {
    if (!StorageService.instance) {
      StorageService.instance = new StorageService();
    }
    return StorageService.instance;
  }

  public onPendingSyncCountChange(callback: (count: number) => void): () => void {
    this.pendingSyncCountCallbacks.add(callback);
    callback(this.getPendingQueue().length);
    return () => {
      this.pendingSyncCountCallbacks.delete(callback);
    };
  }

  public getPendingQueue(): any[] {
    try {
      const saved = localStorage.getItem(this.syncQueueKey);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  }

  private savePendingQueue(queue: any[]) {
    localStorage.setItem(this.syncQueueKey, JSON.stringify(queue));
    this.pendingSyncCountCallbacks.forEach((cb) => cb(queue.length));
  }

  public getLocalCachedData(userId: string): SyncedDataPayload | null {
    try {
      const saved = localStorage.getItem(`${this.localDataKey}_${userId}`);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  }

  public saveLocalCachedData(userId: string, data: SyncedDataPayload) {
    try {
      localStorage.setItem(`${this.localDataKey}_${userId}`, JSON.stringify(data));
    } catch (e) {
      console.error('Error caching financial data locally:', e);
    }
  }

  public async fetchCloudData(userId: string): Promise<SyncedDataPayload | null> {
    if (!platformService.isOnline()) {
      return this.getLocalCachedData(userId);
    }

    try {
      const res = await fetch('/api/sync/get', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
      const data = await res.json();
      if (res.ok && data.success && data.financialData) {
        const payload: SyncedDataPayload = {
          categories: data.financialData.categories || [],
          accounts: data.financialData.accounts || [],
          transactions: data.financialData.transactions || [],
          budgets: data.financialData.budgets || [],
          savingsGoals: data.financialData.savingsGoals || [],
          recurringTransactions: data.financialData.recurringTransactions || [],
        };
        this.saveLocalCachedData(userId, payload);
        return payload;
      }
    } catch (err) {
      console.warn('Unable to fetch cloud sync data, falling back to cached local storage:', err);
    }

    return this.getLocalCachedData(userId);
  }

  public async pushSyncData(userId: string, payload: SyncedDataPayload): Promise<boolean> {
    // Cache locally immediately so UI is always instant & persistent
    this.saveLocalCachedData(userId, payload);

    if (!platformService.isOnline()) {
      // Record in offline pending queue
      const queue = this.getPendingQueue();
      queue.push({
        userId,
        timestamp: new Date().toISOString(),
        payload,
      });
      this.savePendingQueue(queue);
      return false;
    }

    try {
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          ...payload,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        return true;
      }
    } catch (err) {
      console.error('Failed to push sync data to server, adding to offline queue:', err);
      const queue = this.getPendingQueue();
      queue.push({
        userId,
        timestamp: new Date().toISOString(),
        payload,
      });
      this.savePendingQueue(queue);
    }

    return false;
  }

  public async flushOfflineQueue(): Promise<void> {
    const queue = this.getPendingQueue();
    if (queue.length === 0 || !platformService.isOnline()) {
      return;
    }

    console.log(`Online connection restored. Syncing ${queue.length} pending offline financial updates...`);
    const remainingQueue: any[] = [];

    for (const item of queue) {
      try {
        const res = await fetch('/api/sync/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: item.userId,
            ...item.payload,
          }),
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          remainingQueue.push(item);
        }
      } catch (err) {
        remainingQueue.push(item);
      }
    }

    this.savePendingQueue(remainingQueue);
  }
}

export const storageService = StorageService.getInstance();
