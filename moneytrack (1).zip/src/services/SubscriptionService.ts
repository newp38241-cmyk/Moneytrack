import { UserProfile, UserSubscription } from '../types';
import { platformService } from './PlatformService';

export interface VerifySubscriptionResult {
  success: boolean;
  userProfile?: UserProfile;
  subscriptionDetails?: any;
  error?: string;
}

export class SubscriptionService {
  private static instance: SubscriptionService;

  public static getInstance(): SubscriptionService {
    if (!SubscriptionService.instance) {
      SubscriptionService.instance = new SubscriptionService();
    }
    return SubscriptionService.instance;
  }

  public async purchaseAndVerify(
    userId: string,
    planId: string = 'moneytrack_premium_yearly'
  ): Promise<VerifySubscriptionResult> {
    const platform = platformService.getPlatform();

    let purchaseToken = `token_${platform}_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

    // If native Capacitor InAppPurchase is available on device, call native platform purchase flow
    if (platformService.isNativeMobile() && (window as any).Capacitor?.Plugins?.InAppPurchase) {
      try {
        const result = await (window as any).Capacitor.Plugins.InAppPurchase.purchase({ productId: planId });
        if (result && result.receipt) {
          purchaseToken = result.receipt;
        }
      } catch (err: any) {
        console.warn('Native storekit/play billing flow error, using fallback verification:', err);
      }
    }

    try {
      const res = await fetch('/api/subscription/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          platform: platform === 'android' ? 'android_google_play' : platform === 'ios' ? 'ios_apple_storekit' : 'web_payment',
          productId: planId,
          purchaseToken,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Subscription verification failed.' };
      }

      platformService.triggerHapticFeedback('medium');
      return {
        success: true,
        userProfile: data.userProfile,
        subscriptionDetails: data.subscriptionDetails,
      };
    } catch (err: any) {
      return { success: false, error: 'Network request error verifying subscription entitlement.' };
    }
  }
}

export const subscriptionService = SubscriptionService.getInstance();
