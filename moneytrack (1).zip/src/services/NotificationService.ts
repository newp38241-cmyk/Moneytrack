import { platformService } from './PlatformService';

export class NotificationService {
  private static instance: NotificationService;

  public static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  public async requestPermissions(): Promise<boolean> {
    if (typeof window === 'undefined') return false;

    if (platformService.isNativeMobile() && (window as any).Capacitor?.Plugins?.LocalNotifications) {
      try {
        const status = await (window as any).Capacitor.Plugins.LocalNotifications.requestPermissions();
        return status.display === 'granted';
      } catch (err) {
        console.warn('Native notification permission error:', err);
      }
    }

    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }

    return false;
  }

  public async sendNotification(title: string, body: string, id: number = Math.floor(Math.random() * 10000)) {
    if (platformService.isNativeMobile() && (window as any).Capacitor?.Plugins?.LocalNotifications) {
      try {
        await (window as any).Capacitor.Plugins.LocalNotifications.schedule({
          notifications: [
            {
              title,
              body,
              id,
              schedule: { at: new Date(Date.now() + 1000) },
              smallIcon: 'ic_stat_icon_config_sample',
              iconColor: '#4F46E5',
            },
          ],
        });
        return;
      } catch (err) {
        console.warn('Native local notification send error:', err);
      }
    }

    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: '/pwa-icon.png',
      });
    }
  }

  public scheduleDailyReminder(hour: number = 20, minute: number = 0) {
    this.sendNotification(
      'MoneyTrack Reminder',
      'Remember to log your daily expenses and check your budget balance today!'
    );
  }
}

export const notificationService = NotificationService.getInstance();
