export type TargetPlatform = 'web' | 'android' | 'ios';

export interface NetworkStatus {
  connected: boolean;
  connectionType?: 'wifi' | 'cellular' | 'none' | 'unknown';
}

export class PlatformService {
  private static instance: PlatformService;
  private isOnlineStatus: boolean = navigator.onLine;
  private networkListeners: Set<(status: NetworkStatus) => void> = new Set();

  private constructor() {
    window.addEventListener('online', () => this.handleNetworkChange(true));
    window.addEventListener('offline', () => this.handleNetworkChange(false));
  }

  public static getInstance(): PlatformService {
    if (!PlatformService.instance) {
      PlatformService.instance = new PlatformService();
    }
    return PlatformService.instance;
  }

  public getPlatform(): TargetPlatform {
    const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;

    if ((window as any).Capacitor) {
      const nativePlatform = (window as any).Capacitor.getPlatform();
      if (nativePlatform === 'android') return 'android';
      if (nativePlatform === 'ios') return 'ios';
    }

    if (/android/i.test(userAgent)) {
      return 'android';
    }
    if (/iPad|iPhone|iPod/.test(userAgent) && !(window as any).MSStream) {
      return 'ios';
    }

    return 'web';
  }

  public isNativeMobile(): boolean {
    return (window as any).Capacitor?.isNativePlatform() || false;
  }

  public isOnline(): boolean {
    return this.isOnlineStatus;
  }

  public onNetworkStatusChange(callback: (status: NetworkStatus) => void): () => void {
    this.networkListeners.add(callback);
    // Initial call
    callback({ connected: this.isOnlineStatus });

    return () => {
      this.networkListeners.delete(callback);
    };
  }

  private handleNetworkChange(connected: boolean) {
    this.isOnlineStatus = connected;
    const status: NetworkStatus = { connected };
    this.networkListeners.forEach((listener) => listener(status));
  }

  public triggerHapticFeedback(style: 'light' | 'medium' | 'heavy' = 'light') {
    try {
      if ((window as any).Capacitor?.Plugins?.Haptics) {
        (window as any).Capacitor.Plugins.Haptics.impact({ style: style.toUpperCase() });
      } else if (navigator.vibrate) {
        const durations = { light: 10, medium: 25, heavy: 50 };
        navigator.vibrate(durations[style]);
      }
    } catch {
      // Ignore vibration errors on unsupported devices
    }
  }
}

export const platformService = PlatformService.getInstance();
