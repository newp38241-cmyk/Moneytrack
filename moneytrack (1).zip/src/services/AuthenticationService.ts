import { UserProfile } from '../types';
import { platformService } from './PlatformService';

export interface AuthResult {
  success: boolean;
  userProfile?: UserProfile;
  token?: string;
  financialData?: any;
  error?: string;
}

export class AuthenticationService {
  private static instance: AuthenticationService;
  private tokenKey = 'moneytrack_auth_token_v2';
  private cachedProfileKey = 'moneytrack_auth_profile_v2';

  public static getInstance(): AuthenticationService {
    if (!AuthenticationService.instance) {
      AuthenticationService.instance = new AuthenticationService();
    }
    return AuthenticationService.instance;
  }

  public getSavedToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  public getSavedProfile(): UserProfile | null {
    try {
      const saved = localStorage.getItem(this.cachedProfileKey);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  }

  public saveAuthSession(token: string, profile: UserProfile) {
    localStorage.setItem(this.tokenKey, token);
    localStorage.setItem(this.cachedProfileKey, JSON.stringify(profile));
  }

  public clearAuthSession() {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.cachedProfileKey);
  }

  public async loginWithEmail(email: string, pass: string): Promise<AuthResult> {
    if (!platformService.isOnline()) {
      const cachedProfile = this.getSavedProfile();
      if (cachedProfile && cachedProfile.email.toLowerCase() === email.trim().toLowerCase()) {
        return { success: true, userProfile: cachedProfile, token: this.getSavedToken() || 'offline_token' };
      }
      return { success: false, error: 'You are currently offline. Please connect to the internet to sign in.' };
    }

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Login failed.' };
      }

      this.saveAuthSession(data.token, data.userProfile);
      return {
        success: true,
        userProfile: data.userProfile,
        token: data.token,
        financialData: data.financialData,
      };
    } catch (err: any) {
      return { success: false, error: 'Network request failed. Please check your connection.' };
    }
  }

  public async signupWithEmail(email: string, pass: string, name: string): Promise<AuthResult> {
    if (!platformService.isOnline()) {
      return { success: false, error: 'An internet connection is required to create a new MoneyTrack account.' };
    }

    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass, name }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Account creation failed.' };
      }

      this.saveAuthSession(data.token, data.userProfile);
      return {
        success: true,
        userProfile: data.userProfile,
        token: data.token,
        financialData: data.financialData,
      };
    } catch (err: any) {
      return { success: false, error: 'Network request failed. Please check your connection.' };
    }
  }

  public async loginWithGoogle(googleUser: { email: string; name: string; picture?: string }): Promise<AuthResult> {
    if (!platformService.isOnline()) {
      const cachedProfile = this.getSavedProfile();
      if (cachedProfile && cachedProfile.email.toLowerCase() === googleUser.email.trim().toLowerCase()) {
        return { success: true, userProfile: cachedProfile, token: this.getSavedToken() || 'offline_token' };
      }
      return { success: false, error: 'You are currently offline. Please connect to the internet for Google authentication.' };
    }

    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(googleUser),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Google Authentication failed.' };
      }

      this.saveAuthSession(data.token, data.userProfile);
      return {
        success: true,
        userProfile: data.userProfile,
        token: data.token,
        financialData: data.financialData,
      };
    } catch (err: any) {
      return { success: false, error: 'Google Sign-In request failed.' };
    }
  }

  public async sendPasswordReset(email: string): Promise<{ success: boolean; error?: string; message?: string }> {
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'Password reset request failed.' };
      }
      return { success: true, message: data.message };
    } catch {
      return { success: false, error: 'Network error sending password reset request.' };
    }
  }
}

export const authenticationService = AuthenticationService.getInstance();
