import React, { useState, useEffect } from 'react';
import { X, Mail, Lock, User, LogIn, UserPlus, KeyRound, CheckCircle2, AlertCircle, ShieldCheck, Plus, Trash2 } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { UserAvatar } from './UserAvatar';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SavedGoogleAccount {
  email: string;
  name: string;
  picture?: string;
}

const GOOGLE_ACCOUNTS_KEY = 'moneytrack_google_device_accounts_v1';

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const {
    loginWithEmail,
    signupWithEmail,
    loginWithGoogle,
    sendPasswordReset,
    logout,
    isLoggedIn,
    userProfile,
  } = useFinance();

  const [mode, setMode] = useState<'selection' | 'email_login' | 'email_signup' | 'forgot'>('selection');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  
  // Google sign in modal state
  const [isGooglePopupOpen, setIsGooglePopupOpen] = useState(false);
  const [googleSavedAccounts, setGoogleSavedAccounts] = useState<SavedGoogleAccount[]>([]);
  const [isAddingNewGoogleAccount, setIsAddingNewGoogleAccount] = useState(false);
  const [googleEmailInput, setGoogleEmailInput] = useState('');
  const [googleNameInput, setGoogleNameInput] = useState('');
  const [googlePhotoInput, setGooglePhotoInput] = useState('');

  useEffect(() => {
    try {
      const saved = localStorage.getItem(GOOGLE_ACCOUNTS_KEY);
      if (saved) {
        setGoogleSavedAccounts(JSON.parse(saved));
      }
    } catch {
      setGoogleSavedAccounts([]);
    }
  }, [isGooglePopupOpen]);

  if (!isOpen) return null;

  const handleResetForm = () => {
    setErrorMsg('');
    setSuccessMsg('');
  };

  const handleGoogleAuth = () => {
    handleResetForm();
    setIsGooglePopupOpen(true);
    const saved = localStorage.getItem(GOOGLE_ACCOUNTS_KEY);
    const parsed: SavedGoogleAccount[] = saved ? JSON.parse(saved) : [];
    if (parsed.length === 0) {
      setIsAddingNewGoogleAccount(true);
    } else {
      setIsAddingNewGoogleAccount(false);
    }
  };

  const confirmGoogleAccount = (user: { name: string; email: string; picture?: string }) => {
    // Save to device list
    const existing = googleSavedAccounts.filter((a) => a.email.toLowerCase() !== user.email.toLowerCase());
    const updated = [
      { name: user.name, email: user.email.toLowerCase(), picture: user.picture || '' },
      ...existing,
    ];
    localStorage.setItem(GOOGLE_ACCOUNTS_KEY, JSON.stringify(updated));
    setGoogleSavedAccounts(updated);

    loginWithGoogle({
      email: user.email,
      name: user.name,
      picture: user.picture || undefined,
    });

    setIsGooglePopupOpen(false);
    setSuccessMsg('Signed in with Google as ' + user.name);
    setTimeout(() => {
      onClose();
      handleResetForm();
      setMode('selection');
    }, 600);
  };

  const handleAddNewGoogleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = googleEmailInput.trim().toLowerCase();
    const cleanName = googleNameInput.trim() || cleanEmail.split('@')[0];

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      setErrorMsg('Please enter a valid Google email address.');
      return;
    }

    confirmGoogleAccount({
      email: cleanEmail,
      name: cleanName,
      picture: googlePhotoInput.trim() || undefined,
    });
  };

  const removeSavedGoogleAccount = (e: React.MouseEvent, emailToRemove: string) => {
    e.stopPropagation();
    const updated = googleSavedAccounts.filter((a) => a.email.toLowerCase() !== emailToRemove.toLowerCase());
    localStorage.setItem(GOOGLE_ACCOUNTS_KEY, JSON.stringify(updated));
    setGoogleSavedAccounts(updated);
    if (updated.length === 0) {
      setIsAddingNewGoogleAccount(true);
    }
  };

  const handleSubmitEmail = (e: React.FormEvent) => {
    e.preventDefault();
    handleResetForm();

    if (mode === 'forgot') {
      const res = sendPasswordReset(email);
      if (!res.success) {
        setErrorMsg(res.error || 'Failed to send reset link.');
      } else {
        setSuccessMsg('Password reset instructions sent to ' + email);
        setTimeout(() => setMode('email_login'), 2000);
      }
      return;
    }

    if (mode === 'email_signup') {
      const res = signupWithEmail(email, password, name || email.split('@')[0]);
      if (!res.success) {
        setErrorMsg(res.error || 'Signup failed.');
      } else {
        setSuccessMsg('Account created successfully!');
        setTimeout(() => {
          onClose();
          handleResetForm();
          setMode('selection');
        }, 600);
      }
      return;
    }

    if (mode === 'email_login') {
      const res = loginWithEmail(email, password);
      if (!res.success) {
        setErrorMsg(res.error || 'Login failed.');
      } else {
        setSuccessMsg('Logged in successfully!');
        setTimeout(() => {
          onClose();
          handleResetForm();
          setMode('selection');
        }, 600);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl shadow-2xl p-6 text-[#0F172A] dark:text-slate-100 space-y-5 animate-scaleUp relative overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-full bg-[#F1F5F9] dark:bg-slate-800 transition"
        >
          <X className="w-4 h-4" />
        </button>

        {isLoggedIn ? (
          <div className="text-center space-y-4 py-2">
            <UserAvatar name={userProfile.name} pictureUrl={userProfile.pictureUrl} size="xl" className="mx-auto" />

            <div>
              <h3 className="text-lg font-black text-[#0F172A] dark:text-white">{userProfile.name}</h3>
              <p className="text-xs text-[#64748B] dark:text-slate-400 font-medium">{userProfile.email}</p>
              
              <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-400 text-xs font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>Account Sync Active ({userProfile.authProvider === 'google' ? 'Google Auth' : 'Email Auth'})</span>
              </div>
            </div>

            <button
              onClick={() => {
                logout();
                onClose();
              }}
              className="w-full py-3 px-4 rounded-2xl font-bold text-xs bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60 transition"
            >
              Sign Out of MoneyTrack
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Header */}
            <div className="text-center space-y-1">
              <div className="w-10 h-10 bg-[#4F46E5] rounded-xl flex items-center justify-center text-white mx-auto mb-2 shadow-sm">
                <div className="w-5 h-5 border-2 border-white rounded-sm rotate-45 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 bg-white rounded-full" />
                </div>
              </div>
              <h3 className="text-xl font-black text-[#0F172A] dark:text-white tracking-tight">
                Welcome to MoneyTrack
              </h3>
              <p className="text-xs text-[#64748B] dark:text-slate-400 font-medium">
                Know Your Money. Control Your Future.
              </p>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 dark:bg-rose-950/50 dark:border-rose-900 text-rose-700 dark:text-rose-400 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 dark:bg-emerald-950/50 dark:border-emerald-900 text-emerald-700 dark:text-emerald-400 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Mode 1: Main Selection Screen */}
            {mode === 'selection' && (
              <div className="space-y-3 pt-2">
                {/* OPTION 1: Continue with Google */}
                <button
                  type="button"
                  onClick={handleGoogleAuth}
                  className="w-full py-3.5 px-4 rounded-2xl font-bold text-xs bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-[#0F172A] dark:text-white border border-[#E2E8F0] dark:border-slate-700 shadow-xs flex items-center justify-center gap-3 transition active:scale-[0.99]"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Continue with Google</span>
                </button>

                <div className="relative flex py-1 items-center">
                  <div className="flex-grow border-t border-[#E2E8F0] dark:border-slate-800" />
                  <span className="flex-shrink mx-3 text-[11px] text-[#64748B] dark:text-slate-500 font-semibold uppercase">or</span>
                  <div className="flex-grow border-t border-[#E2E8F0] dark:border-slate-800" />
                </div>

                {/* OPTION 2: Continue with Email */}
                <button
                  type="button"
                  onClick={() => {
                    handleResetForm();
                    setMode('email_login');
                  }}
                  className="w-full py-3.5 px-4 rounded-2xl font-bold text-xs bg-[#4F46E5] hover:bg-[#4338CA] text-white shadow-xs flex items-center justify-center gap-2 transition active:scale-[0.99]"
                >
                  <Mail className="w-4 h-4" />
                  <span>Continue with Email</span>
                </button>

                {/* Links: Create Account & Forgot Password */}
                <div className="pt-2 flex items-center justify-between text-xs font-semibold text-[#64748B] dark:text-slate-400">
                  <button
                    type="button"
                    onClick={() => {
                      handleResetForm();
                      setMode('email_signup');
                    }}
                    className="text-[#4F46E5] dark:text-indigo-400 hover:underline"
                  >
                    Create Account
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      handleResetForm();
                      setMode('forgot');
                    }}
                    className="hover:text-[#0F172A] dark:hover:text-white hover:underline text-[11px]"
                  >
                    Forgot Password?
                  </button>
                </div>
              </div>
            )}

            {/* Mode 2: Email Login / Email Signup / Forgot Form */}
            {mode !== 'selection' && (
              <form onSubmit={handleSubmitEmail} className="space-y-3.5 pt-1">
                {mode === 'email_signup' && (
                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] dark:text-slate-300 mb-1">Full Name</label>
                    <div className="relative">
                      <User className="w-4 h-4 text-[#94A3B8] absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        placeholder="Aryan Sheikh"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-[#0F172A] dark:text-white focus:border-[#4F46E5] focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-[#0F172A] dark:text-slate-300 mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-[#94A3B8] absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      placeholder="user@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-[#0F172A] dark:text-white focus:border-[#4F46E5] focus:outline-none"
                    />
                  </div>
                </div>

                {mode !== 'forgot' && (
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-[#0F172A] dark:text-slate-300">Password</label>
                      {mode === 'email_login' && (
                        <button
                          type="button"
                          onClick={() => {
                            handleResetForm();
                            setMode('forgot');
                          }}
                          className="text-[11px] text-[#4F46E5] dark:text-indigo-400 font-semibold hover:underline"
                        >
                          Forgot Password?
                        </button>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-[#94A3B8] absolute left-3 top-3" />
                      <input
                        type="password"
                        required
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-[#0F172A] dark:text-white focus:border-[#4F46E5] focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3.5 px-4 rounded-2xl font-bold text-xs bg-[#4F46E5] hover:bg-[#4338CA] text-white shadow-xs flex items-center justify-center gap-2 transition active:scale-[0.99]"
                >
                  {mode === 'email_login' && <LogIn className="w-4 h-4" />}
                  {mode === 'email_signup' && <UserPlus className="w-4 h-4" />}
                  {mode === 'forgot' && <KeyRound className="w-4 h-4" />}
                  <span>
                    {mode === 'email_login' && 'Sign In with Email'}
                    {mode === 'email_signup' && 'Create MoneyTrack Account'}
                    {mode === 'forgot' && 'Send Password Reset Link'}
                  </span>
                </button>

                <div className="flex items-center justify-between text-xs font-semibold text-[#64748B] pt-2 border-t border-[#E2E8F0] dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      handleResetForm();
                      setMode('selection');
                    }}
                    className="hover:text-[#0F172A] dark:hover:text-white"
                  >
                    ← Back to choices
                  </button>

                  {mode === 'email_login' ? (
                    <button
                      type="button"
                      onClick={() => {
                        handleResetForm();
                        setMode('email_signup');
                      }}
                      className="text-[#4F46E5] dark:text-indigo-400 hover:underline"
                    >
                      Need an account?
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        handleResetForm();
                        setMode('email_login');
                      }}
                      className="text-[#4F46E5] dark:text-indigo-400 hover:underline"
                    >
                      Already registered?
                    </button>
                  )}
                </div>
              </form>
            )}

            {/* Google Pick / Authenticate Account Dialog */}
            {isGooglePopupOpen && (
              <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-5 border border-[#E2E8F0] dark:border-slate-800 space-y-4 shadow-2xl animate-scaleUp">
                  <div className="flex items-center justify-between border-b border-[#E2E8F0] dark:border-slate-800 pb-2">
                    <div className="flex items-center gap-2">
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                      </svg>
                      <span className="font-bold text-xs text-[#0F172A] dark:text-white">Google Accounts</span>
                    </div>
                    <button onClick={() => setIsGooglePopupOpen(false)} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {!isAddingNewGoogleAccount && googleSavedAccounts.length > 0 ? (
                    <div className="space-y-3">
                      <p className="text-[11px] text-[#64748B] dark:text-slate-400">Select a Google account to continue to MoneyTrack:</p>

                      <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                        {googleSavedAccounts.map((acct) => (
                          <div
                            key={acct.email}
                            onClick={() => confirmGoogleAccount(acct)}
                            className="w-full p-2.5 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 hover:bg-indigo-50/60 dark:hover:bg-slate-800 border border-[#E2E8F0] dark:border-slate-800 flex items-center justify-between cursor-pointer transition text-left group"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <UserAvatar name={acct.name} pictureUrl={acct.picture} size="sm" />
                              <div className="overflow-hidden">
                                <p className="font-bold text-xs text-[#0F172A] dark:text-white truncate">{acct.name}</p>
                                <p className="text-[10px] text-[#64748B] dark:text-slate-400 truncate">{acct.email}</p>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={(e) => removeSavedGoogleAccount(e, acct.email)}
                              title="Remove account from device list"
                              className="p-1 text-slate-400 hover:text-rose-500 rounded-lg transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setGoogleEmailInput('');
                          setGoogleNameInput('');
                          setGooglePhotoInput('');
                          setIsAddingNewGoogleAccount(true);
                        }}
                        className="w-full py-2.5 px-3 rounded-2xl bg-[#F1F5F9] dark:bg-slate-800 hover:bg-[#E2E8F0] dark:hover:bg-slate-700 text-xs font-bold text-[#0F172A] dark:text-white flex items-center justify-center gap-2 transition"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Use another Google Account</span>
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleAddNewGoogleSubmit} className="space-y-3">
                      <p className="text-[11px] text-[#64748B] dark:text-slate-400">
                        Enter your Google Account credentials to sign in:
                      </p>

                      <div>
                        <label className="block text-[11px] font-bold text-[#0F172A] dark:text-slate-300 mb-1">Google Email</label>
                        <input
                          type="email"
                          required
                          placeholder="e.g. user@gmail.com"
                          value={googleEmailInput}
                          onChange={(e) => setGoogleEmailInput(e.target.value)}
                          className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-2.5 text-xs text-[#0F172A] dark:text-white focus:border-[#4F46E5] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-[#0F172A] dark:text-slate-300 mb-1">Account Full Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Aryan Sheikh"
                          value={googleNameInput}
                          onChange={(e) => setGoogleNameInput(e.target.value)}
                          className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-2.5 text-xs text-[#0F172A] dark:text-white focus:border-[#4F46E5] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-[#0F172A] dark:text-slate-300 mb-1">
                          Google Profile Photo URL <span className="text-slate-400 font-normal">(Optional)</span>
                        </label>
                        <input
                          type="url"
                          placeholder="https://lh3.googleusercontent.com/..."
                          value={googlePhotoInput}
                          onChange={(e) => setGooglePhotoInput(e.target.value)}
                          className="w-full bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 rounded-xl p-2.5 text-xs text-[#0F172A] dark:text-white focus:border-[#4F46E5] focus:outline-none"
                        />
                        <p className="text-[10px] text-slate-400 mt-1">
                          If left blank, clean initials (e.g. AS) will be used as your avatar.
                        </p>
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="submit"
                          className="flex-1 py-2.5 px-3 rounded-xl bg-[#4F46E5] hover:bg-[#4338CA] text-white font-bold text-xs shadow-xs"
                        >
                          Sign In with Google
                        </button>

                        {googleSavedAccounts.length > 0 && (
                          <button
                            type="button"
                            onClick={() => setIsAddingNewGoogleAccount(false)}
                            className="py-2.5 px-3 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 hover:bg-[#E2E8F0] text-[#0F172A] dark:text-slate-200 font-bold text-xs"
                          >
                            Back
                          </button>
                        )}
                      </div>
                    </form>
                  )}
                </div>
              </div>
            )}

            <div className="text-center pt-1 border-t border-[#E2E8F0] dark:border-slate-800">
              <span className="text-[10px] text-[#94A3B8] dark:text-slate-500 font-medium flex items-center justify-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-500" />
                Isolated Financial Data Encryption
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
