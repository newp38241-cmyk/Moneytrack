import React, { useState } from 'react';
import { Wallet, Check, ArrowRight, Sparkles, DollarSign, PiggyBank, Target } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { SUPPORTED_CURRENCIES } from '../data/initialData';

interface OnboardingModalProps {
  isOpen: boolean;
  onComplete: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ isOpen, onComplete }) => {
  const { userProfile, updateUserProfile, addAccount, setCategoryBudget, addSavingsGoal } = useFinance();

  const [step, setStep] = useState<number>(1);
  const [selectedCurrency, setSelectedCurrency] = useState(userProfile.currency || SUPPORTED_CURRENCIES[0]);
  const [accountName, setAccountName] = useState<string>('Main Bank Account');
  const [startingBalance, setStartingBalance] = useState<string>('25000');
  const [monthlyBudget, setMonthlyBudget] = useState<string>('10000');
  const [goalName, setGoalName] = useState<string>('Emergency Savings');
  const [goalTarget, setGoalTarget] = useState<string>('50000');

  if (!isOpen) return null;

  const handleNext = () => {
    if (step === 1) {
      setStep(2);
    } else if (step === 2) {
      updateUserProfile({ currency: selectedCurrency });
      setStep(3);
    } else if (step === 3) {
      const bal = parseFloat(startingBalance) || 0;
      if (accountName.trim()) {
        addAccount({
          name: accountName.trim(),
          type: 'bank',
          balance: bal,
          icon: 'Landmark',
          color: '#3b82f6',
        });
      }
      setStep(4);
    } else if (step === 4) {
      const bAmount = parseFloat(monthlyBudget);
      if (!isNaN(bAmount) && bAmount > 0) {
        setCategoryBudget('cat-food', bAmount * 0.4);
        setCategoryBudget('cat-shopping', bAmount * 0.3);
        setCategoryBudget('cat-bills', bAmount * 0.3);
      }
      setStep(5);
    } else if (step === 5) {
      const target = parseFloat(goalTarget);
      if (goalName.trim() && !isNaN(target) && target > 0) {
        addSavingsGoal({
          name: goalName.trim(),
          targetAmount: target,
          currentAmount: 0,
          targetDate: '2026-12-31',
          categoryIcon: 'PiggyBank',
          color: '#10b981',
        });
      }
      updateUserProfile({ hasCompletedOnboarding: true });
      onComplete();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden p-6 text-slate-100 space-y-6 animate-scaleUp">
        {/* Progress Dots */}
        <div className="flex items-center justify-center gap-1.5">
          {[1, 2, 3, 4, 5].map((s) => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                s === step ? 'w-8 bg-emerald-500' : s < step ? 'w-3 bg-emerald-500/50' : 'w-3 bg-slate-800'
              }`}
            />
          ))}
        </div>

        {/* Step 1: Welcome */}
        {step === 1 && (
          <div className="text-center space-y-4 py-4 animate-fadeIn">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/25">
              <Wallet className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight text-white">Welcome to MoneyTrack</h2>
              <p className="text-sm text-slate-400 mt-1">Know Your Money. Control Your Future.</p>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800">
              MoneyTrack is your simple, fast, and privacy-focused personal finance assistant. Track expenses in seconds, manage budgets, and hit savings goals.
            </p>
          </div>
        )}

        {/* Step 2: Currency */}
        {step === 2 && (
          <div className="space-y-4 animate-fadeIn">
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-2 border border-emerald-500/30">
                <DollarSign className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold">Choose Your Primary Currency</h3>
              <p className="text-xs text-slate-400 mt-0.5">You can change this anytime in settings.</p>
            </div>

            <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1">
              {SUPPORTED_CURRENCIES.map((curr) => {
                const isSelected = selectedCurrency.code === curr.code;
                return (
                  <button
                    key={curr.code}
                    type="button"
                    onClick={() => setSelectedCurrency(curr)}
                    className={`p-3 rounded-xl border text-left flex items-center justify-between transition ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-500/15 text-white font-bold'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div>
                      <p className="text-xs font-bold">{curr.name}</p>
                      <p className="text-[10px] text-slate-400">{curr.code}</p>
                    </div>
                    <span className="text-base font-black text-emerald-400">{curr.symbol}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 3: Primary Account */}
        {step === 3 && (
          <div className="space-y-4 animate-fadeIn">
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto mb-2 border border-indigo-500/30">
                <Wallet className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold">Add Your Primary Account</h3>
              <p className="text-xs text-slate-400 mt-0.5">Where do you keep your money?</p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Account Name
                </label>
                <input
                  type="text"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  placeholder="e.g. HDFC Bank, Wallet, Cash"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Starting Balance ({selectedCurrency.symbol})
                </label>
                <input
                  type="number"
                  value={startingBalance}
                  onChange={(e) => setStartingBalance(e.target.value)}
                  placeholder="0"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white font-bold focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Monthly Budget */}
        {step === 4 && (
          <div className="space-y-4 animate-fadeIn">
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-2 border border-amber-500/30">
                <PiggyBank className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold">Set Monthly Budget Limit</h3>
              <p className="text-xs text-slate-400 mt-0.5">Optional monthly expense spending limit</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                Target Monthly Budget ({selectedCurrency.symbol})
              </label>
              <input
                type="number"
                value={monthlyBudget}
                onChange={(e) => setMonthlyBudget(e.target.value)}
                placeholder="10000"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white font-bold focus:border-emerald-500 focus:outline-none"
              />
              <p className="text-[11px] text-slate-500 mt-1.5">
                We will automatically configure initial category allocations for Food, Shopping, and Bills.
              </p>
            </div>
          </div>
        )}

        {/* Step 5: Savings Goal */}
        {step === 5 && (
          <div className="space-y-4 animate-fadeIn">
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center mx-auto mb-2 border border-teal-500/30">
                <Target className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold">Create Your First Savings Goal</h3>
              <p className="text-xs text-slate-400 mt-0.5">Build habits for what matters to you.</p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Goal Name
                </label>
                <input
                  type="text"
                  value={goalName}
                  onChange={(e) => setGoalName(e.target.value)}
                  placeholder="e.g. New Phone, Emergency Fund"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Target Amount ({selectedCurrency.symbol})
                </label>
                <input
                  type="number"
                  value={goalTarget}
                  onChange={(e) => setGoalTarget(e.target.value)}
                  placeholder="50000"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white font-bold focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Action Button */}
        <button
          type="button"
          onClick={handleNext}
          className="w-full py-3.5 px-4 rounded-2xl font-bold text-sm bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition active:scale-[0.99]"
        >
          <span>{step === 5 ? 'Get Started' : 'Continue'}</span>
          {step === 5 ? <Check className="w-5 h-5" /> : <ArrowRight className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
};
