import React from 'react';
import { Eye, EyeOff, Search, Bell, Wallet, ShieldCheck } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';

import { UserAvatar } from './UserAvatar';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenNotifications: () => void;
  onOpenAuth: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSearch, onOpenNotifications, onOpenAuth }) => {
  const { userProfile, updateUserProfile, isLoggedIn } = useFinance();

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md text-[#0F172A] dark:text-slate-100 border-b border-[#E2E8F0] dark:border-slate-800 shadow-xs transition-colors duration-200 pt-[env(safe-area-inset-top)]">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-12 sm:h-16 flex items-center justify-between">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl overflow-hidden shrink-0 shadow-sm border border-slate-700/50">
            <img src="/favicon.svg" alt="MoneyTrack" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="font-extrabold tracking-tight text-base sm:text-xl text-[#0F172A] dark:text-white">
                MoneyTrack
              </span>
              <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.2 sm:px-2 sm:py-0.5 rounded-md sm:rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-[#4F46E5] dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/50">
                BENTO
              </span>
            </div>
            <p className="text-[11px] text-[#64748B] dark:text-slate-400 font-medium hidden sm:block">
              Know Your Money. Control Your Future.
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Privacy Eye Toggle */}
          <button
            onClick={() => updateUserProfile({ privacyMode: !userProfile.privacyMode })}
            title={userProfile.privacyMode ? 'Show Balances' : 'Hide Balances'}
            className="p-2 sm:p-2.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-lg sm:rounded-xl bg-[#F1F5F9] hover:bg-[#E2E8F0] dark:bg-slate-800 dark:hover:bg-slate-700 transition"
          >
            {userProfile.privacyMode ? (
              <EyeOff className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-500" />
            ) : (
              <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            )}
          </button>

          {/* Global Search */}
          <button
            onClick={onOpenSearch}
            title="Search Transactions"
            className="p-2 sm:p-2.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-lg sm:rounded-xl bg-[#F1F5F9] hover:bg-[#E2E8F0] dark:bg-slate-800 dark:hover:bg-slate-700 transition"
          >
            <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>

          {/* Notifications */}
          <button
            onClick={onOpenNotifications}
            title="Reminders & Notifications"
            className="p-2 sm:p-2.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-lg sm:rounded-xl bg-[#F1F5F9] hover:bg-[#E2E8F0] dark:bg-slate-800 dark:hover:bg-slate-700 transition relative"
          >
            <Bell className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="absolute top-1 sm:top-1.5 right-1 sm:right-1.5 w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-[#4F46E5] animate-pulse" />
          </button>

          {/* User Profile / Auth Button */}
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-1.5 pl-1 pr-2 sm:pl-1.5 sm:pr-3 py-1 rounded-full bg-[#F1F5F9] hover:bg-[#E2E8F0] dark:bg-slate-800 dark:hover:bg-slate-700 border border-[#E2E8F0] dark:border-slate-700 transition text-[11px] sm:text-xs font-semibold text-[#0F172A] dark:text-slate-200"
          >
            <UserAvatar name={userProfile.name} pictureUrl={userProfile.pictureUrl} size="sm" />
            <span className="max-w-[55px] sm:max-w-[70px] truncate">
              {isLoggedIn ? userProfile.name.split(' ')[0] : 'Guest'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
