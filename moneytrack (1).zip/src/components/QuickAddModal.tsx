import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, CreditCard, Tag, FileText, Camera, Repeat, Check, AlertCircle, ArrowRightLeft } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { TransactionType, RecurrenceInterval } from '../types';
import { CategoryIcon } from './CategoryIcon';

interface QuickAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: TransactionType;
}

export const QuickAddModal: React.FC<QuickAddModalProps> = ({ isOpen, onClose, initialType = 'expense' }) => {
  const { categories, accounts, addTransaction, userProfile } = useFinance();

  const [type, setType] = useState<TransactionType>(initialType);
  const [amount, setAmount] = useState<string>('');
  const [categoryId, setCategoryId] = useState<string>('');
  const [accountId, setAccountId] = useState<string>('');
  const [toAccountId, setToAccountId] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState<string>(new Date().toTimeString().slice(0, 5));
  const [note, setNote] = useState<string>('');
  const [attachmentUrl, setAttachmentUrl] = useState<string>('');
  const [isRecurring, setIsRecurring] = useState<boolean>(false);
  const [recurrenceInterval, setRecurrenceInterval] = useState<RecurrenceInterval>('monthly');
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      setType(initialType);
      setAmount('');
      setNote('');
      setAttachmentUrl('');
      setIsRecurring(false);
      setErrorMessage('');
      setDate(new Date().toISOString().split('T')[0]);
      setTime(new Date().toTimeString().slice(0, 5));

      // Select default category & account
      const availableCats = categories.filter((c) => c.type === (initialType === 'income' ? 'income' : 'expense'));
      if (availableCats.length > 0) setCategoryId(availableCats[0].id);

      if (accounts.length > 0) {
        setAccountId(accounts[0].id);
        if (accounts.length > 1) setToAccountId(accounts[1].id);
      }
    }
  }, [isOpen, initialType, categories, accounts]);

  // Filter categories by type
  const filteredCategories = categories.filter((c) => c.type === (type === 'income' ? 'income' : 'expense'));

  // Quick preset amount buttons
  const presetAmounts = [100, 500, 1000, 5000];

  const handleAddAmount = (addVal: number) => {
    const current = parseFloat(amount) || 0;
    setAmount((current + addVal).toString());
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachmentUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setErrorMessage('Please enter a valid amount greater than 0.');
      return;
    }

    if (type !== 'transfer' && !categoryId) {
      setErrorMessage('Please select a category.');
      return;
    }

    if (!accountId) {
      setErrorMessage('Please select an account.');
      return;
    }

    if (type === 'transfer' && accountId === toAccountId) {
      setErrorMessage('Source and Destination accounts must be different.');
      return;
    }

    addTransaction({
      type,
      amount: parsedAmount,
      categoryId: type === 'transfer' ? 'cat-other-exp' : categoryId,
      accountId,
      toAccountId: type === 'transfer' ? toAccountId : undefined,
      date,
      time,
      note: note.trim(),
      attachmentUrl,
      isRecurring,
      recurrenceInterval: isRecurring ? recurrenceInterval : 'none',
    });

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 sm:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-slideUp">
        {/* Header */}
        <div className="p-4 border-b border-[#E2E8F0] dark:border-slate-800 flex items-center justify-between bg-white/90 dark:bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <h2 className="font-extrabold text-lg text-[#0F172A] dark:text-slate-100">Add Transaction</h2>
            <span className="text-[10px] text-[#4F46E5] dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 px-2.5 py-0.5 rounded-full font-bold">
              Fast Mode
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-full bg-[#F1F5F9] dark:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto flex-1">
          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 dark:bg-rose-500/10 dark:border-rose-500/30 text-rose-700 dark:text-rose-400 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Type Selector (Expense / Income / Transfer) */}
          <div className="grid grid-cols-3 gap-2 bg-[#F1F5F9] dark:bg-slate-950 p-1.5 rounded-2xl border border-[#E2E8F0] dark:border-slate-800">
            <button
              type="button"
              onClick={() => {
                setType('expense');
                const available = categories.filter((c) => c.type === 'expense');
                if (available.length > 0) setCategoryId(available[0].id);
              }}
              className={`py-2 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                type === 'expense'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-[#64748B] dark:text-slate-400 hover:text-[#0F172A]'
              }`}
            >
              Expense
            </button>
            <button
              type="button"
              onClick={() => {
                setType('income');
                const available = categories.filter((c) => c.type === 'income');
                if (available.length > 0) setCategoryId(available[0].id);
              }}
              className={`py-2 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                type === 'income'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-[#64748B] dark:text-slate-400 hover:text-[#0F172A]'
              }`}
            >
              Income
            </button>
            <button
              type="button"
              onClick={() => setType('transfer')}
              className={`py-2 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                type === 'transfer'
                  ? 'bg-[#4F46E5] text-white shadow-xs'
                  : 'text-[#64748B] dark:text-slate-400 hover:text-[#0F172A]'
              }`}
            >
              Transfer
            </button>
          </div>

          {/* Large Amount Display */}
          <div className="bg-[#F8FAFC] dark:bg-slate-950 p-4 rounded-2xl border border-[#E2E8F0] dark:border-slate-800 text-center">
            <label className="block text-[11px] font-bold text-[#64748B] dark:text-slate-400 uppercase tracking-wider mb-1">
              Amount ({userProfile.currency.symbol})
            </label>
            <div className="flex items-center justify-center gap-1">
              <span className="text-2xl font-extrabold text-[#64748B] dark:text-slate-400">{userProfile.currency.symbol}</span>
              <input
                type="number"
                step="any"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                autoFocus
                className="w-full text-center text-3xl font-black bg-transparent text-[#0F172A] dark:text-white outline-none placeholder-[#94A3B8] focus:ring-0"
              />
            </div>

            {/* Quick Add Presets */}
            <div className="flex items-center justify-center gap-2 mt-3 pt-3 border-t border-[#E2E8F0] dark:border-slate-800">
              <span className="text-[10px] text-[#64748B] dark:text-slate-500 font-semibold">Presets:</span>
              {presetAmounts.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleAddAmount(preset)}
                  className="px-3 py-1 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 text-[#0F172A] dark:text-slate-200 font-bold text-xs border border-[#E2E8F0] dark:border-slate-700 transition"
                >
                  +{userProfile.currency.symbol}{preset}
                </button>
              ))}
            </div>
          </div>

          {/* Category Selection (For Expense & Income) */}
          {type !== 'transfer' && (
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5" /> Category
              </label>
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-h-36 overflow-y-auto p-1">
                {filteredCategories.map((cat) => {
                  const isSelected = categoryId === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setCategoryId(cat.id)}
                      className={`flex flex-col items-center justify-center p-2 rounded-xl text-center border transition ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-500/15 text-white font-bold'
                          : 'border-slate-800 bg-slate-950/40 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center mb-1 shadow-sm"
                        style={{ backgroundColor: `${cat.color}25`, color: cat.color }}
                      >
                        <CategoryIcon name={cat.icon} size={16} />
                      </div>
                      <span className="text-[10px] truncate w-full">{cat.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Account Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <CreditCard className="w-3.5 h-3.5" /> {type === 'transfer' ? 'From Account' : 'Account'}
              </label>
              <select
                value={accountId}
                onChange={(e) => setAccountId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-100 text-xs rounded-xl p-2.5 focus:border-emerald-500 focus:outline-none"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name} ({userProfile.currency.symbol}{acc.balance})
                  </option>
                ))}
              </select>
            </div>

            {type === 'transfer' && (
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <ArrowRightLeft className="w-3.5 h-3.5" /> To Account
                </label>
                <select
                  value={toAccountId}
                  onChange={(e) => setToAccountId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-100 text-xs rounded-xl p-2.5 focus:border-emerald-500 focus:outline-none"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} ({userProfile.currency.symbol}{acc.balance})
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" /> Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-100 text-xs rounded-xl p-2.5 focus:border-emerald-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> Time
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-100 text-xs rounded-xl p-2.5 focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Note */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" /> Note / Description
            </label>
            <input
              type="text"
              placeholder="e.g. Lunch at Cafe, Grocery bill..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-100 text-xs rounded-xl p-2.5 focus:border-emerald-500 focus:outline-none placeholder-slate-600"
            />
          </div>

          {/* Optional Attachment / Receipt upload */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
              <Camera className="w-3.5 h-3.5" /> Receipt Attachment (Optional)
            </label>
            <div className="flex items-center gap-3">
              <label className="cursor-pointer px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-300 flex items-center gap-2 transition">
                <Camera className="w-4 h-4 text-emerald-400" />
                <span>Upload / Snap Receipt</span>
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              </label>
              {attachmentUrl && (
                <div className="relative w-10 h-10 rounded-lg overflow-hidden border border-slate-700">
                  <img src={attachmentUrl} alt="Receipt preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setAttachmentUrl('')}
                    className="absolute top-0 right-0 bg-rose-500 text-white rounded-bl p-0.5"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Recurring Switch */}
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Repeat className="w-4 h-4 text-indigo-400" />
              <div>
                <p className="text-xs font-semibold text-slate-200">Recurring Transaction</p>
                <p className="text-[10px] text-slate-400">Repeat automatically every period</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {isRecurring && (
                <select
                  value={recurrenceInterval}
                  onChange={(e) => setRecurrenceInterval(e.target.value as RecurrenceInterval)}
                  className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="yearly">Yearly</option>
                </select>
              )}
              <input
                type="checkbox"
                checked={isRecurring}
                onChange={(e) => setIsRecurring(e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Submit Action */}
          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-2xl font-bold text-sm bg-[#4F46E5] hover:bg-[#4338CA] text-white shadow-sm flex items-center justify-center gap-2 transition active:scale-[0.99]"
          >
            <Check className="w-5 h-5" />
            <span>Save Transaction</span>
          </button>
        </form>
      </div>
    </div>
  );
};
