import React, { useEffect, useState } from 'react';
import { WifiOff, RefreshCw, CheckCircle2 } from 'lucide-react';
import { platformService, NetworkStatus } from '../services/PlatformService';
import { storageService } from '../services/StorageService';

export const OfflineBanner: React.FC = () => {
  const [isOnline, setIsOnline] = useState<boolean>(platformService.isOnline());
  const [pendingCount, setPendingCount] = useState<number>(storageService.getPendingQueue().length);
  const [showSyncedToast, setShowSyncedToast] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  useEffect(() => {
    const unsubscribeNetwork = platformService.onNetworkStatusChange((status: NetworkStatus) => {
      const wasOffline = !isOnline;
      setIsOnline(status.connected);

      if (status.connected && wasOffline) {
        setShowSyncedToast(true);
        setTimeout(() => setShowSyncedToast(false), 4000);
      }
    });

    const unsubscribeStorage = storageService.onPendingSyncCountChange((count: number) => {
      setPendingCount(count);
    });

    return () => {
      unsubscribeNetwork();
      unsubscribeStorage();
    };
  }, [isOnline]);

  const handleManualSync = async () => {
    if (!isOnline) return;
    setIsSyncing(true);
    await storageService.flushOfflineQueue();
    setIsSyncing(false);
    setShowSyncedToast(true);
    setTimeout(() => setShowSyncedToast(false), 3000);
  };

  if (showSyncedToast && isOnline && pendingCount === 0) {
    return (
      <div className="bg-emerald-600 text-white text-xs py-1.5 px-4 flex items-center justify-center gap-2 font-medium shadow-sm animate-fadeIn">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>Connected to server. All financial changes synced successfully!</span>
      </div>
    );
  }

  if (isOnline && pendingCount === 0) return null;

  return (
    <div className={`text-xs py-2 px-4 flex items-center justify-between gap-2 font-medium transition-colors ${
      !isOnline ? 'bg-amber-500 text-slate-900' : 'bg-indigo-600 text-white'
    }`}>
      <div className="flex items-center gap-2 truncate">
        {!isOnline ? (
          <>
            <WifiOff className="w-4 h-4 shrink-0 animate-pulse" />
            <span className="truncate">
              <strong>Offline Mode:</strong> Working locally.{' '}
              {pendingCount > 0 ? `${pendingCount} change${pendingCount > 1 ? 's' : ''} queued for sync.` : 'Changes will sync when online.'}
            </span>
          </>
        ) : (
          <>
            <RefreshCw className={`w-3.5 h-3.5 shrink-0 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>Syncing {pendingCount} offline update{pendingCount > 1 ? 's' : ''} to cloud...</span>
          </>
        )}
      </div>

      {isOnline && pendingCount > 0 && (
        <button
          onClick={handleManualSync}
          disabled={isSyncing}
          className="bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg shrink-0 transition"
        >
          {isSyncing ? 'Syncing...' : 'Sync Now'}
        </button>
      )}
    </div>
  );
};
