import React, { useState } from 'react';
import { Search, X, Calendar, CreditCard, Tag, ArrowUpRight, ArrowDownLeft, RefreshCw } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency, formatDateDisplay } from '../utils/formatters';
import { CategoryIcon } from './CategoryIcon';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTransaction?: (id: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onSelectTransaction }) => {
  const { getFilteredTransactions, categories, accounts, userProfile } = useFinance();
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const results = query.trim()
    ? getFilteredTransactions('this_year', undefined, 'all', 'all', 'all', query)
    : [];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-start justify-center p-4 pt-16">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-4 text-slate-100 space-y-3 animate-slideDown max-h-[80vh] flex flex-col">
        {/* Search Bar Input */}
        <div className="relative flex items-center">
          <Search className="w-5 h-5 text-slate-400 absolute left-3.5" />
          <input
            type="text"
            autoFocus
            placeholder="Search by category, note, amount, account, date..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-3 pl-11 pr-10 text-sm text-white focus:border-emerald-500 focus:outline-none placeholder-slate-500 font-medium"
          />
          {query ? (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 p-1 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onClose}
              className="absolute right-3 p-1 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Results Body */}
        <div className="overflow-y-auto flex-1 space-y-2 pr-1">
          {!query.trim() ? (
            <div className="text-center py-10 space-y-2">
              <Search className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-400 font-medium">Type anything to search across all transactions</p>
              <div className="flex flex-wrap gap-1.5 justify-center pt-2">
                {['Food', 'Salary', '500', 'Bank', 'Yesterday'].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setQuery(preset)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition"
                  >
                    "{preset}"
                  </button>
                ))}
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              No transactions matching "{query}"
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-1">
                Found {results.length} result{results.length > 1 ? 's' : ''}
              </p>
              {results.map((tx) => {
                const category = categories.find((c) => c.id === tx.categoryId);
                const account = accounts.find((a) => a.id === tx.accountId);

                return (
                  <div
                    key={tx.id}
                    onClick={() => {
                      if (onSelectTransaction) onSelectTransaction(tx.id);
                      onClose();
                    }}
                    className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 flex items-center justify-between cursor-pointer transition"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                        style={{
                          backgroundColor: category ? `${category.color}20` : '#334155',
                          color: category ? category.color : '#94a3b8',
                        }}
                      >
                        <CategoryIcon name={category?.icon || 'Tag'} size={20} />
                      </div>
                      <div>
                        <p className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                          <span>{category?.name || 'Transaction'}</span>
                          {tx.note && <span className="text-slate-400 font-normal">· {tx.note}</span>}
                        </p>
                        <p className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                          <span>{account?.name || 'Account'}</span>
                          <span>•</span>
                          <span>{formatDateDisplay(tx.date)}</span>
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p
                        className={`font-black text-sm ${
                          tx.type === 'income'
                            ? 'text-emerald-400'
                            : tx.type === 'expense'
                            ? 'text-rose-400'
                            : 'text-indigo-400'
                        }`}
                      >
                        {tx.type === 'income' ? '+' : tx.type === 'expense' ? '-' : '↔ '}
                        {formatCurrency(tx.amount, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
