import React, { useState } from 'react';
import { Target, Plus, Check, Trash2, X, PlusCircle, MinusCircle } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency, formatDateDisplay } from '../utils/formatters';
import { CategoryIcon } from './CategoryIcon';

export const SavingsGoalsSection: React.FC = () => {
  const { savingsGoals, addSavingsGoal, deleteSavingsGoal, addGoalFunds, userProfile } = useFinance();

  const [isOpenAdd, setIsOpenAdd] = useState(false);
  const [goalName, setGoalName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [targetDate, setTargetDate] = useState('2026-12-31');
  const [icon, setIcon] = useState('PiggyBank');

  // Fund Modal
  const [fundGoalId, setFundGoalId] = useState<string | null>(null);
  const [fundAmount, setFundAmount] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedTarget = parseFloat(targetAmount);
    if (!goalName.trim() || isNaN(parsedTarget) || parsedTarget <= 0) return;

    addSavingsGoal({
      name: goalName.trim(),
      targetAmount: parsedTarget,
      currentAmount: 0,
      targetDate,
      categoryIcon: icon,
      color: '#10b981',
    });

    setIsOpenAdd(false);
    setGoalName('');
    setTargetAmount('');
  };

  const handleAddFundsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(fundAmount);
    if (fundGoalId && !isNaN(amt) && amt !== 0) {
      addGoalFunds(fundGoalId, amt);
      setFundGoalId(null);
      setFundAmount('');
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-xs text-slate-300 uppercase tracking-wider">Savings Goals</h3>
        <button
          onClick={() => setIsOpenAdd(true)}
          className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" /> Add Goal
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {savingsGoals.map((goal) => {
          const percentage = goal.targetAmount > 0 ? (goal.currentAmount / goal.targetAmount) * 100 : 0;
          return (
            <div key={goal.id} className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 space-y-3 shadow-xs">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-100 dark:border-emerald-900">
                    <CategoryIcon name={goal.categoryIcon || 'PiggyBank'} size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-[#0F172A] dark:text-white">{goal.name}</h4>
                    <p className="text-[11px] text-[#64748B] dark:text-slate-400">Target: {formatDateDisplay(goal.targetDate)}</p>
                  </div>
                </div>

                <button
                  onClick={() => deleteSavingsGoal(goal.id)}
                  className="p-1.5 text-[#94A3B8] hover:text-rose-600 rounded-lg transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-emerald-600 dark:text-emerald-400">
                    {formatCurrency(goal.currentAmount, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                  </span>
                  <span className="text-[#64748B] dark:text-slate-400">
                    of {formatCurrency(goal.targetAmount, userProfile.currency.code, userProfile.currency.symbol)}
                  </span>
                </div>

                <div className="w-full h-2 bg-[#F1F5F9] dark:bg-slate-950 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, percentage)}%` }}
                  />
                </div>

                <div className="flex justify-between items-center text-[10px] text-[#64748B] dark:text-slate-400 mt-1 font-semibold">
                  <span>{percentage.toFixed(0)}% Saved</span>
                  <button
                    onClick={() => {
                      setFundGoalId(goal.id);
                      setFundAmount('1000');
                    }}
                    className="text-xs font-bold text-[#4F46E5] hover:underline flex items-center gap-1"
                  >
                    <PlusCircle className="w-3.5 h-3.5" /> Deposit Funds
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Goal Modal */}
      {isOpenAdd && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-slate-100 space-y-4 animate-scaleUp relative">
            <button
              onClick={() => setIsOpenAdd(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-full bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-lg font-bold text-white">New Savings Goal</h3>
            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1 font-semibold">Goal Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Vacation, Car Deposit"
                  value={goalName}
                  onChange={(e) => setGoalName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1 font-semibold">
                  Target Amount ({userProfile.currency.symbol})
                </label>
                <input
                  type="number"
                  required
                  placeholder="50000"
                  value={targetAmount}
                  onChange={(e) => setTargetAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white font-bold"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1 font-semibold">Target Date</label>
                <input
                  type="date"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl font-bold text-xs bg-emerald-500 text-white flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" /> Create Goal
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Deposit Funds Modal */}
      {fundGoalId && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-slate-100 space-y-4 animate-scaleUp relative">
            <button
              onClick={() => setFundGoalId(null)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-full bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-lg font-bold text-white">Deposit / Add Funds</h3>
            <form onSubmit={handleAddFundsSubmit} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1 font-semibold">
                  Amount to Deposit ({userProfile.currency.symbol})
                </label>
                <input
                  type="number"
                  required
                  value={fundAmount}
                  onChange={(e) => setFundAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm text-white font-bold"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl font-bold text-xs bg-emerald-500 text-white flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" /> Add Funds
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
