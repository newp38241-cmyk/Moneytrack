import React from 'react';
import { Crown, Sparkles, X, CheckCircle, ShieldCheck, ArrowRight } from 'lucide-react';
import { FEATURE_INFO, PremiumFeature } from '../utils/accessControl';

interface PremiumLockModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature?: PremiumFeature;
  onUpgradeClick: () => void;
}

export const PremiumLockModal: React.FC<PremiumLockModalProps> = ({
  isOpen,
  onClose,
  feature = 'ADVANCED_REPORTS',
  onUpgradeClick,
}) => {
  if (!isOpen) return null;

  const info = FEATURE_INFO[feature] || FEATURE_INFO['ADVANCED_REPORTS'];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 rounded-3xl shadow-2xl p-6 text-[#0F172A] dark:text-slate-100 space-y-5 animate-scaleUp relative overflow-hidden">
        {/* Top Accent Gradient Bar */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-500 via-indigo-600 to-purple-600" />

        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-full bg-[#F1F5F9] dark:bg-slate-800 transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Icon & Titles */}
        <div className="text-center space-y-2 pt-2">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 p-0.5 shadow-lg shadow-indigo-500/20 mx-auto flex items-center justify-center">
            <div className="w-full h-full bg-white dark:bg-slate-900 rounded-[14px] flex items-center justify-center">
              <Crown className="w-7 h-7 text-amber-500 fill-amber-500/20" />
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" /> Premium Tool
          </div>

          <h2 className="text-2xl font-black text-[#0F172A] dark:text-white tracking-tight">
            Unlock Premium
          </h2>
          <p className="text-xs text-[#64748B] dark:text-slate-400 max-w-xs mx-auto">
            Get more powerful tools to understand and manage your money.
          </p>
        </div>

        {/* Feature Specific Highlight Box */}
        <div className="p-4 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-[#0F172A] dark:text-slate-100 flex items-center gap-2">
              <span>{info.title}</span>
            </h3>
            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-200 dark:border-amber-900/50">
              Available with Premium
            </span>
          </div>
          <p className="text-xs text-[#64748B] dark:text-slate-400 leading-relaxed">
            {info.description}
          </p>
        </div>

        {/* Quick Premium Highlights */}
        <div className="space-y-2 text-xs">
          <div className="flex items-center gap-2 text-[#334155] dark:text-slate-300">
            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>Unlimited accounts, budgets & savings targets</span>
          </div>
          <div className="flex items-center gap-2 text-[#334155] dark:text-slate-300">
            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>Advanced charts, CSV exports & cloud backup</span>
          </div>
          <div className="flex items-center gap-2 text-[#334155] dark:text-slate-300">
            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>Multi-month analytics & custom reminders</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-2">
          <button
            onClick={() => {
              onClose();
              onUpgradeClick();
            }}
            className="w-full py-3.5 px-4 rounded-2xl font-bold text-sm bg-gradient-to-r from-amber-500 via-indigo-600 to-indigo-700 hover:opacity-95 text-white shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 transition active:scale-[0.99]"
          >
            <Crown className="w-4 h-4" />
            <span>Upgrade to Premium</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl font-bold text-xs text-[#64748B] dark:text-slate-400 hover:text-[#0F172A] dark:hover:text-white hover:bg-[#F1F5F9] dark:hover:bg-slate-800 transition"
          >
            Maybe Later
          </button>
        </div>

        <div className="text-center pt-1">
          <span className="text-[10px] text-[#94A3B8] dark:text-slate-500 flex items-center justify-center gap-1 font-medium">
            <ShieldCheck className="w-3 h-3 text-emerald-500" />
            Cancel anytime • MoneyTrack Security Guaranteed
          </span>
        </div>
      </div>
    </div>
  );
};
