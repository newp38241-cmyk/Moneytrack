import React from 'react';

interface UserAvatarProps {
  name: string;
  pictureUrl?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const getInitials = (name?: string): string => {
  if (!name || !name.trim()) return 'MT';
  const clean = name.trim();
  const parts = clean.split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return clean.slice(0, 2).toUpperCase();
};

export const UserAvatar: React.FC<UserAvatarProps> = ({
  name,
  pictureUrl,
  size = 'md',
  className = '',
}) => {
  const initials = getInitials(name);

  const sizeClasses = {
    sm: 'w-6 h-6 text-[10px]',
    md: 'w-8 h-8 text-xs',
    lg: 'w-12 h-12 text-base',
    xl: 'w-16 h-16 text-xl',
  }[size];

  if (pictureUrl && pictureUrl.trim().length > 0) {
    return (
      <img
        src={pictureUrl}
        alt={name}
        className={`${sizeClasses} rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700 ${className}`}
        onError={(e) => {
          // Fallback if avatar URL is broken
          (e.target as HTMLElement).style.display = 'none';
        }}
      />
    );
  }

  return (
    <div
      className={`${sizeClasses} rounded-full bg-gradient-to-tr from-[#4F46E5] to-indigo-600 text-white font-black flex items-center justify-center shrink-0 shadow-xs tracking-wider ${className}`}
      title={name}
    >
      {initials}
    </div>
  );
};
