import React, { useState } from 'react';
import { Repeat, Plus, Trash2, X, Check, Calendar, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency, formatDateDisplay } from '../utils/formatters';
import { RecurrenceInterval, TransactionType } from '../types';

export const RecurringSection: React.FC = () => {
  const { recurringTransactions, addRecurringTransaction, deleteRecurringTransaction, categories, accounts, userProfile } = useFinance();

  const [isOpenAdd, setIsOpenAdd] = useState(false);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<TransactionType>('expense');
  const [categoryId, setCategoryId] = useState('');
  const [accountId, setAccountId] = useState('');
  const [interval, setInterval] = useState<RecurrenceInterval>('monthly');
  const [nextDueDate, setNextDueDate] = useState('2026-09-01');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!title.trim() || isNaN(parsedAmount) || parsedAmount <= 0) return;

    addRecurringTransaction({
      title: title.trim(),
      amount: parsedAmount,
      type,
      categoryId: categoryId || (categories[0]?.id || 'cat-food'),
      accountId: accountId || (accounts[0]?.id || 'acc-bank'),
      interval,
      nextDueDate,
      autoProcess: true,
    });

    setIsOpenAdd(false);
    setTitle('');
    setAmount('');
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-xs text-slate-300 uppercase tracking-wider">Subscriptions & Recurring</h3>
        <button
          onClick={() => {
            setCategoryId(categories[0]?.id || '');
            setAccountId(accounts[0]?.id || '');
            setIsOpenAdd(true);
          }}
          className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" /> Add Recurring
        </button>
      </div>

      <div className="space-y-2">
        {recurringTransactions.length === 0 ? (
          <p className="text-xs text-[#64748B] dark:text-slate-500 py-3 text-center font-medium">No recurring transactions configured.</p>
        ) : (
          recurringTransactions.map((rec) => (
            <div
              key={rec.id}
              className="p-3.5 rounded-2xl bg-[#F8FAFC] dark:bg-slate-950 border border-[#E2E8F0] dark:border-slate-800 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    rec.type === 'income' ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400' : 'bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400'
                  }`}
                >
                  <Repeat className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-[#0F172A] dark:text-slate-100">{rec.title}</h4>
                  <p className="text-[10px] text-[#64748B] dark:text-slate-400 flex items-center gap-2 mt-0.5">
                    <span className="capitalize">{rec.interval}</span>
                    <span>•</span>
                    <span>Next: {formatDateDisplay(rec.nextDueDate)}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <p className={`font-black text-xs ${rec.type === 'income' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                  {rec.type === 'income' ? '+' : '-'}
                  {formatCurrency(rec.amount, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                </p>

                <button
                  onClick={() => deleteRecurringTransaction(rec.id)}
                  className="p-1.5 text-[#94A3B8] hover:text-rose-600 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal */}
      {isOpenAdd && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-slate-100 space-y-4 animate-scaleUp relative">
            <button
              onClick={() => setIsOpenAdd(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-full bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-lg font-bold text-white">Add Recurring Bill / Income</h3>
            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1 font-semibold">Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Netflix Subscription, House Rent"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs text-slate-400 mb-1 font-semibold">Type</label>
                  <select
                    value={type}
                    onChange={(e: any) => setType(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="expense">Expense</option>
                    <option value="income">Income</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1 font-semibold">Frequency</label>
                  <select
                    value={interval}
                    onChange={(e: any) => setInterval(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1 font-semibold">
                  Amount ({userProfile.currency.symbol})
                </label>
                <input
                  type="number"
                  required
                  placeholder="1000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white font-bold"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1 font-semibold">Next Due Date</label>
                <input
                  type="date"
                  value={nextDueDate}
                  onChange={(e) => setNextDueDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl font-bold text-xs bg-emerald-500 text-white flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" /> Save Recurring Item
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
