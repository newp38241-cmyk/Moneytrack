import { SubscriptionPlan } from '../types';

export type PremiumFeature =
  | 'UNLIMITED_ACCOUNTS'
  | 'UNLIMITED_BUDGETS'
  | 'UNLIMITED_GOALS'
  | 'UNLIMITED_CUSTOM_CATEGORIES'
  | 'UNLIMITED_RECURRING'
  | 'ADVANCED_REPORTS'
  | 'CSV_EXPORT'
  | 'ADVANCED_BACKUP'
  | 'ADVANCED_REMINDERS'
  | 'PREMIUM_THEMES'
  | 'YEARLY_COMPARISON';

export const FREE_LIMITS = {
  MAX_ACCOUNTS: 3,
  MAX_BUDGETS: 5,
  MAX_SAVINGS_GOALS: 2,
  MAX_CUSTOM_CATEGORIES: 3,
  MAX_RECURRING: 2,
};

export interface FeatureMetadata {
  id: PremiumFeature;
  title: string;
  description: string;
}

export const FEATURE_INFO: Record<PremiumFeature, FeatureMetadata> = {
  UNLIMITED_ACCOUNTS: {
    id: 'UNLIMITED_ACCOUNTS',
    title: 'Unlimited Accounts',
    description: 'Track all your bank accounts, credit cards, UPI IDs, and cash wallets without limits.',
  },
  UNLIMITED_BUDGETS: {
    id: 'UNLIMITED_BUDGETS',
    title: 'Unlimited Category Budgets',
    description: 'Set spending targets across every category to keep complete control of your finances.',
  },
  UNLIMITED_GOALS: {
    id: 'UNLIMITED_GOALS',
    title: 'Unlimited Savings Goals',
    description: 'Create multi-target savings plans for emergency funds, vacations, investments, and big buys.',
  },
  UNLIMITED_CUSTOM_CATEGORIES: {
    id: 'UNLIMITED_CUSTOM_CATEGORIES',
    title: 'Unlimited Custom Categories',
    description: 'Organize income and expenses with personalized icons, colors, and category tags.',
  },
  UNLIMITED_RECURRING: {
    id: 'UNLIMITED_RECURRING',
    title: 'Unlimited Recurring Bills',
    description: 'Automate subscription tracking, recurring rent, bill payments, and salary inflows.',
  },
  ADVANCED_REPORTS: {
    id: 'ADVANCED_REPORTS',
    title: 'Advanced Financial Reports',
    description: 'Unlock multi-month comparisons, deep historical trends, and category breakdown charts.',
  },
  CSV_EXPORT: {
    id: 'CSV_EXPORT',
    title: 'CSV Data Export',
    description: 'Export all your transaction history into structured spreadsheet files anytime.',
  },
  ADVANCED_BACKUP: {
    id: 'ADVANCED_BACKUP',
    title: 'Cloud Backup & Restore',
    description: 'Seamlessly backup and restore complete financial profiles across devices.',
  },
  ADVANCED_REMINDERS: {
    id: 'ADVANCED_REMINDERS',
    title: 'Advanced Reminders & Alerts',
    description: 'Receive custom notification alerts before bills are due or when budgets near limits.',
  },
  PREMIUM_THEMES: {
    id: 'PREMIUM_THEMES',
    title: 'Premium Themes & Customization',
    description: 'Personalize MoneyTrack with dark modes, custom accent colors, and dense dashboard layouts.',
  },
  YEARLY_COMPARISON: {
    id: 'YEARLY_COMPARISON',
    title: 'Yearly & Historical Analytics',
    description: 'Analyze multi-year income vs expense ratios to track long-term net worth growth.',
  },
};

/**
 * Centralized feature access check function
 * Returns true if the user plan allows the feature
 */
export function canAccess(plan: SubscriptionPlan, feature: PremiumFeature): boolean {
  if (plan === 'PREMIUM') return true;

  // Free plan restrictions
  switch (feature) {
    case 'UNLIMITED_ACCOUNTS':
    case 'UNLIMITED_BUDGETS':
    case 'UNLIMITED_GOALS':
    case 'UNLIMITED_CUSTOM_CATEGORIES':
    case 'UNLIMITED_RECURRING':
    case 'ADVANCED_REPORTS':
    case 'CSV_EXPORT':
    case 'ADVANCED_BACKUP':
    case 'ADVANCED_REMINDERS':
    case 'PREMIUM_THEMES':
    case 'YEARLY_COMPARISON':
      return false;
    default:
      return true;
  }
}

export function checkLimit(
  plan: SubscriptionPlan,
  limitType: 'ACCOUNTS' | 'BUDGETS' | 'GOALS' | 'CUSTOM_CATEGORIES' | 'RECURRING',
  currentCount: number
): boolean {
  if (plan === 'PREMIUM') return true;

  switch (limitType) {
    case 'ACCOUNTS':
      return currentCount < FREE_LIMITS.MAX_ACCOUNTS;
    case 'BUDGETS':
      return currentCount < FREE_LIMITS.MAX_BUDGETS;
    case 'GOALS':
      return currentCount < FREE_LIMITS.MAX_SAVINGS_GOALS;
    case 'CUSTOM_CATEGORIES':
      return currentCount < FREE_LIMITS.MAX_CUSTOM_CATEGORIES;
    case 'RECURRING':
      return currentCount < FREE_LIMITS.MAX_RECURRING;
    default:
      return true;
  }
}
