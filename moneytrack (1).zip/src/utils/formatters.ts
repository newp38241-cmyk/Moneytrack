export const formatCurrency = (
  amount: number,
  currencyCode: string = 'INR',
  currencySymbol: string = '₹',
  privacyMode: boolean = false
): string => {
  if (privacyMode) return '••••••';
  
  const absAmount = Math.abs(amount);
  const formattedNumber = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(absAmount);

  const sign = amount < 0 ? '-' : '';
  
  if (currencyCode === 'INR') {
    return `${sign}${currencySymbol}${formattedNumber}`;
  }
  return `${sign}${currencySymbol}${formattedNumber}`;
};

export const formatDateDisplay = (dateString: string): string => {
  if (!dateString) return '';
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  if (dateString === today) return 'Today';
  if (dateString === yesterday) return 'Yesterday';

  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
};

export const exportTransactionsToCSV = (transactions: any[], categories: any[], accounts: any[], currencySymbol: string = '₹') => {
  const categoryMap = new Map(categories.map((c: any) => [c.id, c.name]));
  const accountMap = new Map(accounts.map((a: any) => [a.id, a.name]));

  const headers = ['ID', 'Date', 'Time', 'Type', 'Amount', 'Category', 'Account', 'To Account', 'Note'];
  const rows = transactions.map((t: any) => [
    t.id,
    t.date,
    t.time || '',
    t.type.toUpperCase(),
    `${currencySymbol}${t.amount}`,
    categoryMap.get(t.categoryId) || t.categoryId,
    accountMap.get(t.accountId) || t.accountId,
    t.toAccountId ? (accountMap.get(t.toAccountId) || t.toAccountId) : '',
    `"${(t.note || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `MoneyTrack_Transactions_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
