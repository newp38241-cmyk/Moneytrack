import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  DEFAULT_ACCOUNTS,
  DEFAULT_BUDGETS,
  DEFAULT_EXPENSE_CATEGORIES,
  DEFAULT_INCOME_CATEGORIES,
  DEFAULT_RECURRING,
  DEFAULT_SAVINGS_GOALS,
  DEFAULT_TRANSACTIONS,
  DEFAULT_USER_PROFILE,
} from '../data/initialData';
import {
  Account,
  Category,
  CategoryBudget,
  DateRange,
  RecurringTransaction,
  SavingsGoal,
  SubscriptionPlan,
  TimePeriod,
  Transaction,
  UserProfile,
} from '../types';
import { canAccess as canAccessUtil, checkLimit as checkLimitUtil, FREE_LIMITS, PremiumFeature } from '../utils/accessControl';
import { storageService, SyncedDataPayload } from '../services/StorageService';
import { authenticationService } from '../services/AuthenticationService';
import { subscriptionService } from '../services/SubscriptionService';
import { notificationService } from '../services/NotificationService';
import { platformService } from '../services/PlatformService';

interface FinanceContextType {
  userProfile: UserProfile;
  updateUserProfile: (updates: Partial<UserProfile>) => void;
  categories: Category[];
  addCategory: (category: Omit<Category, 'id'>) => boolean;
  updateCategory: (id: string, updates: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  accounts: Account[];
  addAccount: (account: Omit<Account, 'id'>) => boolean;
  updateAccount: (id: string, updates: Partial<Account>) => void;
  deleteAccount: (id: string) => void;
  transactions: Transaction[];
  addTransaction: (tx: Omit<Transaction, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => void;
  updateTransaction: (id: string, tx: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  budgets: CategoryBudget[];
  setCategoryBudget: (categoryId: string, amount: number) => boolean;
  deleteCategoryBudget: (categoryId: string) => void;
  savingsGoals: SavingsGoal[];
  addSavingsGoal: (goal: Omit<SavingsGoal, 'id'>) => boolean;
  updateSavingsGoal: (id: string, updates: Partial<SavingsGoal>) => void;
  deleteSavingsGoal: (id: string) => void;
  addGoalFunds: (goalId: string, amount: number) => void;
  recurringTransactions: RecurringTransaction[];
  addRecurringTransaction: (rec: Omit<RecurringTransaction, 'id'>) => boolean;
  deleteRecurringTransaction: (id: string) => void;
  timePeriod: TimePeriod;
  setTimePeriod: (period: TimePeriod) => void;
  customDateRange: DateRange;
  setCustomDateRange: (range: DateRange) => void;

  // Computed values
  totalIncome: number;
  totalExpense: number;
  totalBalance: number;
  thisMonthIncome: number;
  thisMonthExpense: number;
  thisMonthSavings: number;

  // Access Control & Premium
  canAccess: (feature: PremiumFeature) => boolean;
  checkLimit: (limitType: 'ACCOUNTS' | 'BUDGETS' | 'GOALS' | 'CUSTOM_CATEGORIES' | 'RECURRING', count?: number) => boolean;
  isPremiumLockOpen: boolean;
  lockedFeature: PremiumFeature | null;
  triggerPremiumLock: (feature: PremiumFeature) => void;
  closePremiumLock: () => void;
  verifyAndUpgradePremium: (planId?: string) => Promise<{ success: boolean; error?: string }>;

  // Filtering helper
  getFilteredTransactions: (
    period?: TimePeriod,
    customRange?: DateRange,
    typeFilter?: string,
    categoryFilter?: string,
    accountFilter?: string,
    searchQuery?: string
  ) => Transaction[];

  // Reset & Backup
  resetAllData: () => void;
  restoreFromJSON: (jsonData: string) => boolean;
  exportJSON: () => string;
  isLoggedIn: boolean;
  login: (email: string, name?: string) => void;
  loginWithEmail: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  signupWithEmail: (email: string, pass: string, name: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: (googleUser?: { email: string; name: string; picture?: string }) => Promise<void>;
  sendPasswordReset: (email: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  logout: () => void;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

const LOCAL_STORAGE_KEYS = {
  PROFILE: 'moneytrack_profile_v2',
  AUTH: 'moneytrack_auth_v2',
};

const getUserStorageKey = (userId: string, itemKey: string) => `moneytrack_user_${userId}_${itemKey}`;

export const FinanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.PROFILE);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_USER_PROFILE,
          ...parsed,
          plan: parsed.plan || 'FREE',
          subscriptionStatus: parsed.subscriptionStatus || 'active',
        };
      } catch {
        return DEFAULT_USER_PROFILE;
      }
    }
    return DEFAULT_USER_PROFILE;
  });

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return !!localStorage.getItem(LOCAL_STORAGE_KEYS.AUTH);
  });

  // Premium lock UI modal state
  const [isPremiumLockOpen, setIsPremiumLockOpen] = useState(false);
  const [lockedFeature, setLockedFeature] = useState<PremiumFeature | null>(null);

  const triggerPremiumLock = (feature: PremiumFeature) => {
    platformService.triggerHapticFeedback('medium');
    setLockedFeature(feature);
    setIsPremiumLockOpen(true);
  };

  const closePremiumLock = () => {
    setIsPremiumLockOpen(false);
    setLockedFeature(null);
  };

  // User-scoped data state
  const [categories, setCategories] = useState<Category[]>(() => {
    const key = getUserStorageKey(userProfile.id, 'categories');
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : [...DEFAULT_EXPENSE_CATEGORIES, ...DEFAULT_INCOME_CATEGORIES];
  });

  const [accounts, setAccounts] = useState<Account[]>(() => {
    const key = getUserStorageKey(userProfile.id, 'accounts');
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : DEFAULT_ACCOUNTS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const key = getUserStorageKey(userProfile.id, 'transactions');
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : DEFAULT_TRANSACTIONS;
  });

  const [budgets, setBudgets] = useState<CategoryBudget[]>(() => {
    const key = getUserStorageKey(userProfile.id, 'budgets');
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : DEFAULT_BUDGETS;
  });

  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>(() => {
    const key = getUserStorageKey(userProfile.id, 'goals');
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : DEFAULT_SAVINGS_GOALS;
  });

  const [recurringTransactions, setRecurringTransactions] = useState<RecurringTransaction[]>(() => {
    const key = getUserStorageKey(userProfile.id, 'recurring');
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : DEFAULT_RECURRING;
  });

  const [timePeriod, setTimePeriod] = useState<TimePeriod>('this_month');
  const [customDateRange, setCustomDateRange] = useState<DateRange>({
    startDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
  });

  // Load state whenever active userProfile.id changes or cloud sync completes
  const applyFinancialDataPayload = (data: SyncedDataPayload) => {
    if (data.categories && data.categories.length > 0) setCategories(data.categories);
    if (data.accounts && data.accounts.length > 0) setAccounts(data.accounts);
    if (data.transactions) setTransactions(data.transactions);
    if (data.budgets) setBudgets(data.budgets);
    if (data.savingsGoals) setSavingsGoals(data.savingsGoals);
    if (data.recurringTransactions) setRecurringTransactions(data.recurringTransactions);
  };

  // Initial cloud sync fetch on mount
  useEffect(() => {
    if (isLoggedIn && userProfile.id) {
      storageService.fetchCloudData(userProfile.id).then((cloudData) => {
        if (cloudData) {
          applyFinancialDataPayload(cloudData);
        }
      });
    }
  }, [userProfile.id, isLoggedIn]);

  // Sync profile changes to localStorage & Cloud
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEYS.PROFILE, JSON.stringify(userProfile));
  }, [userProfile]);

  // Auto push financial changes to Cloud / Offline Queue
  useEffect(() => {
    const payload: SyncedDataPayload = {
      categories,
      accounts,
      transactions,
      budgets,
      savingsGoals,
      recurringTransactions,
      userProfileUpdates: userProfile,
    };
    storageService.pushSyncData(userProfile.id, payload);
  }, [categories, accounts, transactions, budgets, savingsGoals, recurringTransactions, userProfile]);

  // Access control checking methods
  const canAccess = (feature: PremiumFeature): boolean => {
    return canAccessUtil(userProfile.plan, feature);
  };

  const checkLimit = (
    limitType: 'ACCOUNTS' | 'BUDGETS' | 'GOALS' | 'CUSTOM_CATEGORIES' | 'RECURRING',
    count?: number
  ): boolean => {
    let currentCount = count;
    if (currentCount === undefined) {
      if (limitType === 'ACCOUNTS') currentCount = accounts.length;
      if (limitType === 'BUDGETS') currentCount = budgets.length;
      if (limitType === 'GOALS') currentCount = savingsGoals.length;
      if (limitType === 'CUSTOM_CATEGORIES') currentCount = categories.filter((c) => c.isCustom).length;
      if (limitType === 'RECURRING') currentCount = recurringTransactions.length;
    }
    return checkLimitUtil(userProfile.plan, limitType, currentCount || 0);
  };

  // Premium entitlement verification
  const verifyAndUpgradePremium = async (planId: string = 'moneytrack_premium_yearly') => {
    const res = await subscriptionService.purchaseAndVerify(userProfile.id, planId);
    if (res.success && res.userProfile) {
      setUserProfile((prev) => ({
        ...prev,
        plan: 'PREMIUM',
        subscriptionStatus: 'active',
      }));
      closePremiumLock();
      notificationService.sendNotification('MoneyTrack Premium Unlocked!', 'Welcome to MoneyTrack Premium. Enjoy unlimited features.');
      return { success: true };
    }
    return { success: false, error: res.error || 'Subscription verification failed.' };
  };

  // Auth helper methods
  const login = (email: string, name?: string) => {
    const sanitizedEmail = email.trim().toLowerCase();
    const userId = `usr_${sanitizedEmail.replace(/[^a-z0-9]/g, '_')}`;

    const newProfile: UserProfile = {
      ...userProfile,
      id: userId,
      email: sanitizedEmail,
      name: name || sanitizedEmail.split('@')[0] || 'MoneyTrack User',
      authProvider: 'email',
    };

    setUserProfile(newProfile);
    localStorage.setItem(LOCAL_STORAGE_KEYS.AUTH, 'true');
    setIsLoggedIn(true);

    storageService.fetchCloudData(userId).then((data) => {
      if (data) applyFinancialDataPayload(data);
    });
  };

  const signupWithEmail = async (email: string, pass: string, name: string) => {
    const res = await authenticationService.signupWithEmail(email, pass, name);
    if (!res.success || !res.userProfile) {
      return { success: false, error: res.error || 'Signup failed.' };
    }

    setUserProfile(res.userProfile);
    localStorage.setItem(LOCAL_STORAGE_KEYS.AUTH, 'true');
    setIsLoggedIn(true);

    if (res.financialData) {
      applyFinancialDataPayload(res.financialData);
    }
    return { success: true };
  };

  const loginWithEmail = async (email: string, pass: string) => {
    const res = await authenticationService.loginWithEmail(email, pass);
    if (!res.success || !res.userProfile) {
      return { success: false, error: res.error || 'Login failed.' };
    }

    setUserProfile(res.userProfile);
    localStorage.setItem(LOCAL_STORAGE_KEYS.AUTH, 'true');
    setIsLoggedIn(true);

    if (res.financialData) {
      applyFinancialDataPayload(res.financialData);
    }
    return { success: true };
  };

  const loginWithGoogle = async (googleUser?: { email: string; name: string; picture?: string }) => {
    const payload = googleUser || {
      email: 'user.google@moneytrack.app',
      name: 'Google User',
      picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=GoogleUser',
    };

    const res = await authenticationService.loginWithGoogle(payload);
    if (res.success && res.userProfile) {
      setUserProfile(res.userProfile);
      localStorage.setItem(LOCAL_STORAGE_KEYS.AUTH, 'true');
      setIsLoggedIn(true);

      if (res.financialData) {
        applyFinancialDataPayload(res.financialData);
      }
    }
  };

  const sendPasswordReset = async (email: string) => {
    return await authenticationService.sendPasswordReset(email);
  };

  const logout = () => {
    authenticationService.clearAuthSession();
    localStorage.removeItem(LOCAL_STORAGE_KEYS.AUTH);
    setIsLoggedIn(false);
    setUserProfile(DEFAULT_USER_PROFILE);
    setCategories([...DEFAULT_EXPENSE_CATEGORIES, ...DEFAULT_INCOME_CATEGORIES]);
    setAccounts(DEFAULT_ACCOUNTS);
    setTransactions(DEFAULT_TRANSACTIONS);
    setBudgets(DEFAULT_BUDGETS);
    setSavingsGoals(DEFAULT_SAVINGS_GOALS);
    setRecurringTransactions(DEFAULT_RECURRING);
  };

  const updateUserProfile = (updates: Partial<UserProfile>) => {
    setUserProfile((prev) => ({ ...prev, ...updates }));
  };

  // Categories CRUD
  const addCategory = (categoryData: Omit<Category, 'id'>): boolean => {
    const customCount = categories.filter((c) => c.isCustom).length;
    if (!checkLimit('CUSTOM_CATEGORIES', customCount)) {
      triggerPremiumLock('UNLIMITED_CUSTOM_CATEGORIES');
      return false;
    }

    const newCategory: Category = {
      ...categoryData,
      id: `cat-custom-${Date.now()}`,
      isCustom: true,
    };
    setCategories((prev) => [...prev, newCategory]);
    return true;
  };

  const updateCategory = (id: string, updates: Partial<Category>) => {
    setCategories((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
  };

  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
  };

  // Accounts CRUD
  const addAccount = (accountData: Omit<Account, 'id'>): boolean => {
    if (!checkLimit('ACCOUNTS', accounts.length)) {
      triggerPremiumLock('UNLIMITED_ACCOUNTS');
      return false;
    }

    const newAccount: Account = {
      ...accountData,
      id: `acc-${Date.now()}`,
    };
    setAccounts((prev) => [...prev, newAccount]);
    return true;
  };

  const updateAccount = (id: string, updates: Partial<Account>) => {
    setAccounts((prev) => prev.map((a) => (a.id === id ? { ...a, ...updates } : a)));
  };

  const deleteAccount = (id: string) => {
    setAccounts((prev) => prev.filter((a) => a.id !== id));
  };

  // Transactions CRUD
  const addTransaction = (txData: Omit<Transaction, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
    const newTx: Transaction = {
      ...txData,
      id: `tx-${Date.now()}`,
      userId: userProfile.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setAccounts((prevAccounts) => {
      return prevAccounts.map((acc) => {
        if (newTx.type === 'income' && acc.id === newTx.accountId) {
          return { ...acc, balance: acc.balance + newTx.amount };
        }
        if (newTx.type === 'expense' && acc.id === newTx.accountId) {
          return { ...acc, balance: acc.balance - newTx.amount };
        }
        if (newTx.type === 'transfer') {
          if (acc.id === newTx.accountId) {
            return { ...acc, balance: acc.balance - newTx.amount };
          }
          if (acc.id === newTx.toAccountId) {
            return { ...acc, balance: acc.balance + newTx.amount };
          }
        }
        return acc;
      });
    });

    setTransactions((prev) => [newTx, ...prev]);
  };

  const updateTransaction = (id: string, updates: Partial<Transaction>) => {
    const oldTx = transactions.find((t) => t.id === id);
    if (!oldTx) return;

    setTransactions((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t))
    );

    if (updates.amount !== undefined || updates.accountId !== undefined || updates.type !== undefined) {
      const updatedTx = { ...oldTx, ...updates };
      setAccounts((prevAccounts) =>
        prevAccounts.map((acc) => {
          let bal = acc.balance;
          if (oldTx.type === 'income' && acc.id === oldTx.accountId) bal -= oldTx.amount;
          if (oldTx.type === 'expense' && acc.id === oldTx.accountId) bal += oldTx.amount;
          if (oldTx.type === 'transfer') {
            if (acc.id === oldTx.accountId) bal += oldTx.amount;
            if (acc.id === oldTx.toAccountId) bal -= oldTx.amount;
          }

          if (updatedTx.type === 'income' && acc.id === updatedTx.accountId) bal += updatedTx.amount;
          if (updatedTx.type === 'expense' && acc.id === updatedTx.accountId) bal -= updatedTx.amount;
          if (updatedTx.type === 'transfer') {
            if (acc.id === updatedTx.accountId) bal -= updatedTx.amount;
            if (acc.id === updatedTx.toAccountId) bal += updatedTx.amount;
          }

          return { ...acc, balance: bal };
        })
      );
    }
  };

  const deleteTransaction = (id: string) => {
    const tx = transactions.find((t) => t.id === id);
    if (!tx) return;

    setAccounts((prevAccounts) =>
      prevAccounts.map((acc) => {
        if (tx.type === 'income' && acc.id === tx.accountId) {
          return { ...acc, balance: acc.balance - tx.amount };
        }
        if (tx.type === 'expense' && acc.id === tx.accountId) {
          return { ...acc, balance: acc.balance + tx.amount };
        }
        if (tx.type === 'transfer') {
          if (acc.id === tx.accountId) {
            return { ...acc, balance: acc.balance + tx.amount };
          }
          if (acc.id === tx.toAccountId) {
            return { ...acc, balance: acc.balance - tx.amount };
          }
        }
        return acc;
      })
    );

    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  // Budgets CRUD
  const setCategoryBudget = (categoryId: string, amount: number): boolean => {
    const existing = budgets.find((b) => b.categoryId === categoryId);
    if (!existing && !checkLimit('BUDGETS', budgets.length)) {
      triggerPremiumLock('UNLIMITED_BUDGETS');
      return false;
    }

    setBudgets((prev) => {
      if (existing) {
        return prev.map((b) => (b.categoryId === categoryId ? { categoryId, amount } : b));
      }
      return [...prev, { categoryId, amount }];
    });
    return true;
  };

  const deleteCategoryBudget = (categoryId: string) => {
    setBudgets((prev) => prev.filter((b) => b.categoryId !== categoryId));
  };

  // Savings Goals CRUD
  const addSavingsGoal = (goalData: Omit<SavingsGoal, 'id'>): boolean => {
    if (!checkLimit('GOALS', savingsGoals.length)) {
      triggerPremiumLock('UNLIMITED_GOALS');
      return false;
    }

    const newGoal: SavingsGoal = {
      ...goalData,
      id: `goal-${Date.now()}`,
    };
    setSavingsGoals((prev) => [...prev, newGoal]);
    return true;
  };

  const updateSavingsGoal = (id: string, updates: Partial<SavingsGoal>) => {
    setSavingsGoals((prev) => prev.map((g) => (g.id === id ? { ...g, ...updates } : g)));
  };

  const deleteSavingsGoal = (id: string) => {
    setSavingsGoals((prev) => prev.filter((g) => g.id !== id));
  };

  const addGoalFunds = (goalId: string, amount: number) => {
    setSavingsGoals((prev) =>
      prev.map((g) => (g.id === goalId ? { ...g, currentAmount: Math.max(0, g.currentAmount + amount) } : g))
    );
  };

  // Recurring CRUD
  const addRecurringTransaction = (recData: Omit<RecurringTransaction, 'id'>): boolean => {
    if (!checkLimit('RECURRING', recurringTransactions.length)) {
      triggerPremiumLock('UNLIMITED_RECURRING');
      return false;
    }

    const newRec: RecurringTransaction = {
      ...recData,
      id: `rec-${Date.now()}`,
    };
    setRecurringTransactions((prev) => [...prev, newRec]);
    return true;
  };

  const deleteRecurringTransaction = (id: string) => {
    setRecurringTransactions((prev) => prev.filter((r) => r.id !== id));
  };

  // Filter Transactions logic
  const getFilteredTransactions = (
    period: TimePeriod = timePeriod,
    customRange: DateRange = customDateRange,
    typeFilter: string = 'all',
    categoryFilter: string = 'all',
    accountFilter: string = 'all',
    searchQuery: string = ''
  ): Transaction[] => {
    const now = new Date();
    let startDate: Date;
    let endDate: Date = new Date();

    switch (period) {
      case 'this_week': {
        const day = now.getDay();
        const diff = now.getDate() - day + (day === 0 ? -6 : 1);
        startDate = new Date(now.setDate(diff));
        startDate.setHours(0, 0, 0, 0);
        endDate = new Date();
        break;
      }
      case 'this_month': {
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
        break;
      }
      case 'last_month': {
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        endDate = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);
        break;
      }
      case 'last_3_months': {
        startDate = new Date(now.getFullYear(), now.getMonth() - 2, 1);
        endDate = new Date();
        break;
      }
      case 'this_year': {
        startDate = new Date(now.getFullYear(), 0, 1);
        endDate = new Date(now.getFullYear(), 11, 31, 23, 59, 59);
        break;
      }
      case 'custom': {
        startDate = new Date(customRange.startDate);
        endDate = new Date(customRange.endDate);
        endDate.setHours(23, 59, 59);
        break;
      }
      default: {
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        endDate = new Date();
      }
    }

    const startStr = startDate.toISOString().split('T')[0];
    const endStr = endDate.toISOString().split('T')[0];

    return transactions.filter((tx) => {
      if (tx.date < startStr || tx.date > endStr) return false;
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;
      if (categoryFilter !== 'all' && tx.categoryId !== categoryFilter) return false;
      if (accountFilter !== 'all' && tx.accountId !== accountFilter && tx.toAccountId !== accountFilter) return false;

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const category = categories.find((c) => c.id === tx.categoryId);
        const account = accounts.find((a) => a.id === tx.accountId);
        const noteMatch = (tx.note || '').toLowerCase().includes(query);
        const categoryMatch = (category?.name || '').toLowerCase().includes(query);
        const accountMatch = (account?.name || '').toLowerCase().includes(query);
        const amountMatch = tx.amount.toString().includes(query);
        const dateMatch = tx.date.includes(query);

        return noteMatch || categoryMatch || accountMatch || amountMatch || dateMatch;
      }

      return true;
    });
  };

  // Computations
  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalBalance = totalIncome - totalExpense;

  const thisMonthTxs = getFilteredTransactions('this_month');
  const thisMonthIncome = thisMonthTxs
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const thisMonthExpense = thisMonthTxs
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const thisMonthSavings = thisMonthIncome - thisMonthExpense;

  // Reset & Backup
  const resetAllData = () => {
    const prefix = `moneytrack_user_${userProfile.id}`;
    localStorage.removeItem(`${prefix}_categories`);
    localStorage.removeItem(`${prefix}_accounts`);
    localStorage.removeItem(`${prefix}_transactions`);
    localStorage.removeItem(`${prefix}_budgets`);
    localStorage.removeItem(`${prefix}_goals`);
    localStorage.removeItem(`${prefix}_recurring`);

    setUserProfile({ ...DEFAULT_USER_PROFILE, id: userProfile.id, hasCompletedOnboarding: false });
    setCategories([...DEFAULT_EXPENSE_CATEGORIES, ...DEFAULT_INCOME_CATEGORIES]);
    setAccounts(DEFAULT_ACCOUNTS);
    setTransactions([]);
    setBudgets(DEFAULT_BUDGETS);
    setSavingsGoals(DEFAULT_SAVINGS_GOALS);
    setRecurringTransactions(DEFAULT_RECURRING);
  };

  const exportJSON = () => {
    const data = {
      userProfile,
      categories,
      accounts,
      transactions,
      budgets,
      savingsGoals,
      recurringTransactions,
      exportedAt: new Date().toISOString(),
    };
    return JSON.stringify(data, null, 2);
  };

  const restoreFromJSON = (jsonData: string): boolean => {
    try {
      const parsed = JSON.parse(jsonData);
      if (parsed.userProfile) setUserProfile(parsed.userProfile);
      if (parsed.categories) setCategories(parsed.categories);
      if (parsed.accounts) setAccounts(parsed.accounts);
      if (parsed.transactions) setTransactions(parsed.transactions);
      if (parsed.budgets) setBudgets(parsed.budgets);
      if (parsed.savingsGoals) setSavingsGoals(parsed.savingsGoals);
      if (parsed.recurringTransactions) setRecurringTransactions(parsed.recurringTransactions);
      return true;
    } catch (e) {
      console.error('Failed to restore from JSON', e);
      return false;
    }
  };

  return (
    <FinanceContext.Provider
      value={{
        userProfile,
        updateUserProfile,
        categories,
        addCategory,
        updateCategory,
        deleteCategory,
        accounts,
        addAccount,
        updateAccount,
        deleteAccount,
        transactions,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        budgets,
        setCategoryBudget,
        deleteCategoryBudget,
        savingsGoals,
        addSavingsGoal,
        updateSavingsGoal,
        deleteSavingsGoal,
        addGoalFunds,
        recurringTransactions,
        addRecurringTransaction,
        deleteRecurringTransaction,
        timePeriod,
        setTimePeriod,
        customDateRange,
        setCustomDateRange,
        totalIncome,
        totalExpense,
        totalBalance,
        thisMonthIncome,
        thisMonthExpense,
        thisMonthSavings,
        canAccess,
        checkLimit,
        isPremiumLockOpen,
        lockedFeature,
        triggerPremiumLock,
        closePremiumLock,
        verifyAndUpgradePremium,
        getFilteredTransactions,
        resetAllData,
        restoreFromJSON,
        exportJSON,
        isLoggedIn,
        login,
        loginWithEmail,
        signupWithEmail,
        loginWithGoogle,
        sendPasswordReset,
        logout,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
};
