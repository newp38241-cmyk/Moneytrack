import React, { useState } from 'react';
import { PieChart, Plus, AlertTriangle, CheckCircle2, Edit2, Trash2, X, Check, Target, ChevronRight } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency } from '../utils/formatters';
import { CategoryIcon } from '../components/CategoryIcon';

interface BudgetViewProps {
  onOpenQuickAdd: () => void;
}

export const BudgetView: React.FC<BudgetViewProps> = ({ onOpenQuickAdd }) => {
  const {
    budgets,
    setCategoryBudget,
    deleteCategoryBudget,
    categories,
    getFilteredTransactions,
    userProfile,
  } = useFinance();

  // Active modal for adding/editing a budget
  const [isOpenModal, setIsOpenModal] = useState(false);
  const [selectedCatId, setSelectedCatId] = useState('');
  const [budgetAmount, setBudgetAmount] = useState('');

  // Calculate category expenses for current month
  const thisMonthExpenses = getFilteredTransactions('this_month').filter((t) => t.type === 'expense');
  const catExpenseMap = new Map<string, number>();

  thisMonthExpenses.forEach((t) => {
    const current = catExpenseMap.get(t.categoryId) || 0;
    catExpenseMap.set(t.categoryId, current + t.amount);
  });

  const expenseCategories = categories.filter((c) => c.type === 'expense');

  // Total budget calculations
  const totalBudget = budgets.reduce((sum, b) => sum + b.amount, 0);
  const totalSpent = budgets.reduce((sum, b) => sum + (catExpenseMap.get(b.categoryId) || 0), 0);
  const totalRemaining = totalBudget - totalSpent;
  const overallPercentage = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

  const handleSaveBudget = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(budgetAmount);
    if (!selectedCatId || isNaN(amount) || amount <= 0) return;

    setCategoryBudget(selectedCatId, amount);
    setIsOpenModal(false);
    setSelectedCatId('');
    setBudgetAmount('');
  };

  const handleOpenEdit = (catId: string, currentAmount: number) => {
    setSelectedCatId(catId);
    setBudgetAmount(currentAmount.toString());
    setIsOpenModal(true);
  };

  return (
    <div className="space-y-4 sm:space-y-5 pb-24 sm:pb-28 animate-fadeIn">
      {/* Overview Bento Card */}
      <div className="rounded-2xl sm:rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 p-4 sm:p-6 text-[#0F172A] dark:text-slate-100 shadow-xs space-y-3.5 sm:space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-[#4F46E5] dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900">
              <PieChart className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-[#0F172A] dark:text-white">Monthly Budget Planner</h2>
              <p className="text-xs text-[#64748B] dark:text-slate-400">Keep your expenses controlled and on target</p>
            </div>
          </div>

          <button
            onClick={() => {
              const unbudgeted = expenseCategories.find((c) => !budgets.some((b) => b.categoryId === c.id));
              setSelectedCatId(unbudgeted ? unbudgeted.id : expenseCategories[0]?.id || '');
              setBudgetAmount('5000');
              setIsOpenModal(true);
            }}
            className="py-2.5 px-4 rounded-xl bg-[#4F46E5] hover:bg-[#4338CA] text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition active:scale-[0.98]"
          >
            <Plus className="w-4 h-4" /> Add Budget
          </button>
        </div>

        {/* Overall Bar */}
        <div className="space-y-2 pt-2">
          <div className="flex justify-between items-end">
            <div>
              <p className="text-[10px] text-[#64748B] dark:text-slate-400 font-semibold uppercase tracking-wider">Total Monthly Spent</p>
              <p className="text-2xl font-extrabold text-[#0F172A] dark:text-white">
                {formatCurrency(totalSpent, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-[#64748B] dark:text-slate-400 font-semibold uppercase tracking-wider">Total Limit</p>
              <p className="text-sm font-bold text-[#475569] dark:text-slate-300">
                {formatCurrency(totalBudget, userProfile.currency.code, userProfile.currency.symbol)}
              </p>
            </div>
          </div>

          <div className="w-full h-3 bg-[#F1F5F9] dark:bg-slate-950 rounded-full overflow-hidden p-0.5 border border-[#E2E8F0] dark:border-slate-800">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                overallPercentage > 100
                  ? 'bg-rose-500'
                  : overallPercentage > 80
                  ? 'bg-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(100, overallPercentage)}%` }}
            />
          </div>

          <div className="flex justify-between text-xs text-[#64748B] dark:text-slate-400 pt-1 font-medium">
            <span className="font-semibold text-[#1E293B] dark:text-slate-300">{overallPercentage.toFixed(0)}% used</span>
            <span>
              {totalRemaining >= 0 ? (
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                  {formatCurrency(totalRemaining, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)} remaining
                </span>
              ) : (
                <span className="text-rose-600 dark:text-rose-400 font-bold">
                  Over limit by {formatCurrency(Math.abs(totalRemaining), userProfile.currency.code, userProfile.currency.symbol)}
                </span>
              )}
            </span>
          </div>
        </div>
      </div>

      {/* Category Budget Grid */}
      <div className="space-y-3">
        <h3 className="font-bold text-xs text-[#64748B] dark:text-slate-400 uppercase tracking-wider px-1">Category Budgets</h3>

        {budgets.length === 0 ? (
          <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-[#E2E8F0] dark:border-slate-800 text-center space-y-3">
            <Target className="w-10 h-10 text-[#94A3B8] dark:text-slate-600 mx-auto" />
            <p className="font-bold text-[#0F172A] dark:text-slate-300 text-sm">No monthly budgets set</p>
            <p className="text-xs text-[#64748B] dark:text-slate-400 max-w-xs mx-auto">
              Create category spending targets (e.g., Food: {userProfile.currency.symbol}5,000) to get automatic progress alerts.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {budgets.map((b) => {
              const category = categories.find((c) => c.id === b.categoryId);
              const spent = catExpenseMap.get(b.categoryId) || 0;
              const remaining = b.amount - spent;
              const percentage = b.amount > 0 ? (spent / b.amount) * 100 : 0;

              const isExceeded = percentage > 100;
              const isWarning = percentage >= 80 && !isExceeded;

              return (
                <div
                  key={b.categoryId}
                  className={`p-5 rounded-3xl bg-white dark:bg-slate-900 border transition shadow-xs ${
                    isExceeded
                      ? 'border-rose-300 bg-rose-50/30 dark:border-rose-500/50 dark:bg-rose-500/5'
                      : isWarning
                      ? 'border-amber-300 bg-amber-50/30 dark:border-amber-500/50 dark:bg-amber-500/5'
                      : 'border-[#E2E8F0] dark:border-slate-800 hover:border-[#4F46E5]'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-xs"
                        style={{
                          backgroundColor: category ? `${category.color}15` : '#f1f5f9',
                          color: category ? category.color : '#64748b',
                        }}
                      >
                        <CategoryIcon name={category?.icon || 'Tag'} size={20} />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-[#0F172A] dark:text-slate-100 flex items-center gap-2">
                          <span>{category?.name || 'Category'}</span>
                          {isExceeded && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-600 dark:bg-rose-500/20 dark:text-rose-400 flex items-center gap-1 border border-rose-200">
                              <AlertTriangle className="w-3 h-3" /> Exceeded
                            </span>
                          )}
                          {isWarning && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400 flex items-center gap-1 border border-amber-200">
                              <AlertTriangle className="w-3 h-3" /> Near Limit
                            </span>
                          )}
                        </h4>
                        <p className="text-xs text-[#64748B] dark:text-slate-400 mt-0.5">
                          Spent{' '}
                          <strong className="text-[#0F172A] dark:text-slate-200 font-bold">
                            {formatCurrency(spent, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                          </strong>{' '}
                          of {formatCurrency(b.amount, userProfile.currency.code, userProfile.currency.symbol)}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(b.categoryId, b.amount)}
                        title="Edit Budget"
                        className="p-1.5 text-[#64748B] hover:text-[#0F172A] dark:text-slate-400 dark:hover:text-white rounded-xl bg-[#F1F5F9] dark:bg-slate-800 transition"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deleteCategoryBudget(b.categoryId)}
                        title="Delete Budget"
                        className="p-1.5 text-[#64748B] hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 rounded-xl bg-[#F1F5F9] dark:bg-slate-800 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-4 space-y-1.5">
                    <div className="w-full h-2 bg-[#F1F5F9] dark:bg-slate-950 rounded-full overflow-hidden p-0.5">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isExceeded ? 'bg-rose-500' : isWarning ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${Math.min(100, percentage)}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[11px] font-semibold text-[#64748B] dark:text-slate-400">
                      <span>{percentage.toFixed(0)}% used</span>
                      <span>
                        {remaining >= 0
                          ? `${formatCurrency(remaining, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)} left`
                          : `Over by ${formatCurrency(Math.abs(remaining), userProfile.currency.code, userProfile.currency.symbol)}`}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add / Edit Budget Modal */}
      {isOpenModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-slate-100 space-y-4 animate-scaleUp relative">
            <button
              onClick={() => setIsOpenModal(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-full bg-slate-800 hover:bg-slate-700 transition"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-lg font-bold text-white">Set Category Budget</h3>

            <form onSubmit={handleSaveBudget} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Expense Category
                </label>
                <select
                  value={selectedCatId}
                  onChange={(e) => setSelectedCatId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white focus:border-emerald-500 focus:outline-none"
                >
                  {expenseCategories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Monthly Budget Limit ({userProfile.currency.symbol})
                </label>
                <input
                  type="number"
                  required
                  placeholder="5000"
                  value={budgetAmount}
                  onChange={(e) => setBudgetAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm font-bold text-white focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl font-bold text-xs bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition"
              >
                <Check className="w-4 h-4" /> Save Budget
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
