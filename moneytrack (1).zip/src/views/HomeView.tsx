import React from 'react';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  PiggyBank,
  Plus,
  ArrowRight,
  ChevronRight,
  TrendingUp,
  PieChart,
  ShieldCheck,
  AlertTriangle,
  Lightbulb,
} from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency, formatDateDisplay } from '../utils/formatters';
import { CategoryIcon } from '../components/CategoryIcon';
import { TransactionType } from '../types';

interface HomeViewProps {
  onOpenQuickAdd: (type?: TransactionType) => void;
  onNavigateToTab: (tab: 'transactions' | 'budget' | 'reports' | 'profile') => void;
  onSelectTransaction: (id: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onOpenQuickAdd,
  onNavigateToTab,
  onSelectTransaction,
}) => {
  const {
    userProfile,
    totalBalance,
    thisMonthIncome,
    thisMonthExpense,
    thisMonthSavings,
    getFilteredTransactions,
    categories,
    accounts,
    budgets,
    savingsGoals,
  } = useFinance();

  const recentTransactions = getFilteredTransactions('this_month').slice(0, 5);

  // Spending by category calculations for current month
  const currentMonthTxs = getFilteredTransactions('this_month').filter((t) => t.type === 'expense');
  const categoryExpensesMap = new Map<string, number>();
  let totalMonthExpenseSum = 0;

  currentMonthTxs.forEach((t) => {
    const current = categoryExpensesMap.get(t.categoryId) || 0;
    categoryExpensesMap.set(t.categoryId, current + t.amount);
    totalMonthExpenseSum += t.amount;
  });

  const topCategoryExpenses = Array.from(categoryExpensesMap.entries())
    .map(([catId, amount]) => {
      const category = categories.find((c) => c.id === catId);
      const percentage = totalMonthExpenseSum > 0 ? (amount / totalMonthExpenseSum) * 100 : 0;
      return { category, amount, percentage };
    })
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 3);

  // Overall budget calculation
  const totalBudgetLimit = budgets.reduce((sum, b) => sum + b.amount, 0);
  const totalBudgetSpent = budgets.reduce((sum, b) => {
    const spent = categoryExpensesMap.get(b.categoryId) || 0;
    return sum + spent;
  }, 0);
  const budgetPercentage = totalBudgetLimit > 0 ? (totalBudgetSpent / totalBudgetLimit) * 100 : 0;

  return (
    <div className="pb-24 sm:pb-28 animate-fadeIn space-y-3.5 sm:space-y-6">
      {/* Bento Grid Layout Container */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 sm:gap-5 lg:gap-6">

        {/* Bento Card 1: Current Total Balance */}
        <div className="col-span-12 md:col-span-6 lg:col-span-4 bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-[#E2E8F0] dark:border-slate-800 p-4 sm:p-6 shadow-xs flex flex-col justify-between space-y-3 sm:space-y-5">
          <div>
            <div className="flex items-center justify-between mb-1 sm:mb-2">
              <p className="text-[#64748B] dark:text-slate-400 text-[11px] sm:text-xs font-semibold uppercase tracking-wider">
                Current Balance
              </p>
              <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-wider px-1.5 sm:px-2 py-0.5 rounded-md sm:rounded-lg bg-[#F1F5F9] dark:bg-slate-800 text-[#475569] dark:text-slate-300">
                {userProfile.currency.code} ({userProfile.currency.symbol})
              </span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-[#0F172A] dark:text-white tracking-tight">
              {formatCurrency(totalBalance, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
            </h1>
            <p className="text-[11px] sm:text-xs text-[#64748B] dark:text-slate-400 mt-0.5 sm:mt-1 font-medium">
              Net balance across all accounts
            </p>
          </div>

          <div className="flex gap-2 pt-1">
            <button
              onClick={() => onOpenQuickAdd('expense')}
              className="flex-1 bg-[#4F46E5] text-white rounded-xl py-2.5 sm:py-3 font-semibold text-xs sm:text-sm hover:bg-[#4338CA] transition shadow-xs flex items-center justify-center gap-1.5 min-h-[42px]"
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>+ Expense</span>
            </button>
            <button
              onClick={() => onOpenQuickAdd('income')}
              className="flex-1 bg-emerald-600 text-white rounded-xl py-2.5 sm:py-3 font-semibold text-xs sm:text-sm hover:bg-emerald-700 transition shadow-xs flex items-center justify-center gap-1.5 min-h-[42px]"
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>+ Income</span>
            </button>
          </div>
        </div>

        {/* Bento Card 2: Income Stat Box */}
        <div className="col-span-6 md:col-span-3 lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-[#E2E8F0] dark:border-slate-800 p-3.5 sm:p-5 shadow-xs flex flex-col justify-center items-center text-center">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-1.5 sm:mb-3 shrink-0">
            <ArrowDownLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <p className="text-[#64748B] dark:text-slate-400 text-[11px] sm:text-xs font-semibold mb-0.5">Income</p>
          <p className="text-base sm:text-xl font-bold text-emerald-600 dark:text-emerald-400 truncate max-w-full px-1">
            +{formatCurrency(thisMonthIncome, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
          </p>
          <p className="text-[9px] sm:text-[10px] text-[#94A3B8] dark:text-slate-500 mt-0.5">This Month</p>
        </div>

        {/* Bento Card 3: Expenses Stat Box */}
        <div className="col-span-6 md:col-span-3 lg:col-span-2 bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-[#E2E8F0] dark:border-slate-800 p-3.5 sm:p-5 shadow-xs flex flex-col justify-center items-center text-center">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-1.5 sm:mb-3 shrink-0">
            <ArrowUpRight className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <p className="text-[#64748B] dark:text-slate-400 text-[11px] sm:text-xs font-semibold mb-0.5">Expenses</p>
          <p className="text-base sm:text-xl font-bold text-rose-600 dark:text-rose-400 truncate max-w-full px-1">
            -{formatCurrency(thisMonthExpense, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
          </p>
          <p className="text-[9px] sm:text-[10px] text-[#94A3B8] dark:text-slate-500 mt-0.5">This Month</p>
        </div>

        {/* Bento Card 4: Monthly Budget Progress */}
        <div className="col-span-12 md:col-span-6 lg:col-span-4 bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-[#E2E8F0] dark:border-slate-800 p-4 sm:p-6 shadow-xs flex flex-col justify-between space-y-3 sm:space-y-4">
          <div>
            <div className="flex items-center justify-between mb-3 sm:mb-4">
              <h3 className="text-xs sm:text-sm font-bold text-[#0F172A] dark:text-white flex items-center gap-2">
                <PieChart className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" />
                <span>Monthly Budget Progress</span>
              </h3>
              <button
                onClick={() => onNavigateToTab('budget')}
                className="text-[11px] font-bold text-[#4F46E5] dark:text-indigo-400 hover:underline flex items-center gap-0.5"
              >
                View <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {topCategoryExpenses.length > 0 ? (
              <div className="space-y-3 sm:space-y-4">
                {topCategoryExpenses.map(({ category, amount, percentage }) => (
                  <div key={category?.id || 'cat'}>
                    <div className="flex justify-between text-xs mb-1 font-medium">
                      <span className="text-[#475569] dark:text-slate-300 flex items-center gap-1.5">
                        <CategoryIcon name={category?.icon || 'Tag'} size={14} color={category?.color} />
                        {category?.name || 'Category'}
                      </span>
                      <span className="text-[#64748B] dark:text-slate-400 font-bold">
                        {formatCurrency(amount, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                      </span>
                    </div>
                    <div className="h-1.5 sm:h-2 bg-[#F1F5F9] dark:bg-slate-950 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${Math.min(100, percentage)}%`,
                          backgroundColor: category?.color || '#4F46E5',
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#64748B] dark:text-slate-400 py-3 sm:py-4 text-center">
                No expense budgets recorded yet.
              </p>
            )}
          </div>

          <div className="bg-[#F8FAFC] dark:bg-slate-950 rounded-xl sm:rounded-2xl p-3 sm:p-4 text-center border border-dashed border-[#E2E8F0] dark:border-slate-800">
            <p className="text-[9px] sm:text-[10px] uppercase font-bold text-[#94A3B8] tracking-widest">Financial Tip</p>
            <p className="text-[11px] sm:text-xs text-[#475569] dark:text-slate-300 leading-relaxed mt-0.5 sm:mt-1">
              {thisMonthSavings >= 0
                ? `You have saved ${formatCurrency(thisMonthSavings, userProfile.currency.code, userProfile.currency.symbol)} this month. Keep up your discipline!`
                : `Your monthly expenses exceed income by ${formatCurrency(Math.abs(thisMonthSavings), userProfile.currency.code, userProfile.currency.symbol)}. Review top spending.`}
            </p>
          </div>
        </div>

        {/* Bento Card 5: Dark Contrast Recent Transactions Card */}
        <div className="col-span-12 md:col-span-6 lg:col-span-4 bg-[#1E293B] text-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-xl relative overflow-hidden flex flex-col justify-between">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          <div>
            <div className="flex justify-between items-center mb-3 sm:mb-5">
              <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                <Wallet className="w-4 h-4 text-indigo-400" />
                <span>Recent Transactions</span>
              </h3>
              <button
                onClick={() => onNavigateToTab('transactions')}
                className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest hover:text-indigo-300"
              >
                View All
              </button>
            </div>

            {recentTransactions.length === 0 ? (
              <div className="py-5 sm:py-8 text-center space-y-2.5 sm:space-y-3">
                <p className="text-xs font-extrabold text-white">No transactions yet</p>
                <p className="text-[11px] text-slate-400 max-w-[220px] mx-auto leading-normal">
                  Start tracking your money by adding your first transaction.
                </p>
                <button
                  onClick={() => onOpenQuickAdd()}
                  className="py-2 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs inline-flex items-center gap-1.5 shadow-sm transition min-h-[40px]"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Add Transaction</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2.5 sm:space-y-3.5">
                {recentTransactions.map((tx) => {
                  const category = categories.find((c) => c.id === tx.categoryId);
                  const account = accounts.find((a) => a.id === tx.accountId);

                  return (
                    <div
                      key={tx.id}
                      onClick={() => onSelectTransaction(tx.id)}
                      className="flex items-center gap-3 group cursor-pointer border-b border-slate-800/80 pb-2.5 sm:pb-3 last:border-0 last:pb-0"
                    >
                      <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-slate-800 flex items-center justify-center text-white shrink-0">
                        <CategoryIcon name={category?.icon || 'Tag'} size={16} color={category?.color || '#a5b4fc'} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <p className="text-xs font-bold text-white truncate pr-2">{category?.name || 'Transaction'}</p>
                          <p
                            className={`text-xs font-extrabold ${
                              tx.type === 'income' ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            {tx.type === 'income' ? '+' : '-'}
                            {formatCurrency(tx.amount, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)}
                          </p>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-0.5 truncate">
                          {formatDateDisplay(tx.date)} • {account?.name || 'Wallet'}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Bento Card 6: Savings Goals Summary */}
        <div className="col-span-12 md:col-span-6 lg:col-span-4 bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl border border-[#E2E8F0] dark:border-slate-800 p-4 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3 sm:mb-5">
              <h3 className="text-xs sm:text-sm font-bold text-[#0F172A] dark:text-white flex items-center gap-2">
                <PiggyBank className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>Savings Goals</span>
              </h3>
              <button
                onClick={() => onNavigateToTab('profile')}
                className="w-7 h-7 rounded-full bg-[#F1F5F9] dark:bg-slate-800 flex items-center justify-center text-xs font-bold hover:bg-[#E2E8F0] text-[#0F172A] dark:text-slate-200 transition"
              >
                +
              </button>
            </div>

            <div className="space-y-3 sm:space-y-4">
              {savingsGoals.slice(0, 2).map((goal) => {
                const percentage = goal.targetAmount > 0 ? (goal.currentAmount / goal.targetAmount) * 100 : 0;
                return (
                  <div key={goal.id} className="p-3 sm:p-4 bg-[#F8FAFC] dark:bg-slate-950/60 rounded-xl sm:rounded-2xl border border-[#F1F5F9] dark:border-slate-800 space-y-2 sm:space-y-2.5">
                    <div className="flex items-center gap-2.5 sm:gap-3">
                      <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 flex items-center justify-center text-[#4F46E5] dark:text-indigo-400 shrink-0">
                        <CategoryIcon name={goal.categoryIcon || 'PiggyBank'} size={15} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-end">
                          <p className="text-xs font-bold text-[#1E293B] dark:text-white truncate">{goal.name}</p>
                          <p className="text-[10px] font-bold text-[#4F46E5] dark:text-indigo-400">{percentage.toFixed(0)}%</p>
                        </div>
                      </div>
                    </div>

                    <div className="h-1.5 bg-[#E2E8F0] dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#4F46E5] rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(100, percentage)}%` }}
                      />
                    </div>

                    <p className="text-[10px] text-[#64748B] dark:text-slate-400 font-medium">
                      {formatCurrency(goal.currentAmount, userProfile.currency.code, userProfile.currency.symbol, userProfile.privacyMode)} saved of {formatCurrency(goal.targetAmount, userProfile.currency.code, userProfile.currency.symbol)}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bento Card 7: Banner for Linked Accounts */}
        <div className="col-span-12 bg-gradient-to-r from-[#4F46E5] to-purple-600 rounded-2xl sm:rounded-3xl p-4 sm:p-5 flex items-center justify-between text-white shadow-lg shadow-indigo-100 dark:shadow-none">
          <div className="flex flex-col">
            <span className="text-[9px] sm:text-[10px] opacity-80 uppercase tracking-widest font-bold">Active Money Accounts</span>
            <span className="text-xs sm:text-sm font-bold mt-0.5">{accounts.length} Wallets & Accounts Configured</span>
          </div>

          <div className="flex -space-x-2">
            {accounts.map((acc, i) => (
              <div
                key={acc.id}
                title={acc.name}
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-full border-2 border-white/20 bg-white/20 backdrop-blur-md flex items-center justify-center text-xs font-bold uppercase shadow-sm"
              >
                {acc.name.charAt(0)}
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
