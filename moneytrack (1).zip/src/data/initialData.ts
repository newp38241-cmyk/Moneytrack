import { Account, Category, CategoryBudget, RecurringTransaction, SavingsGoal, Transaction, UserProfile } from '../types';

export const SUPPORTED_CURRENCIES = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'AED', symbol: 'AED', name: 'UAE Dirham' },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar' },
];

export const DEFAULT_EXPENSE_CATEGORIES: Category[] = [
  { id: 'cat-food', name: 'Food', type: 'expense', icon: 'Utensils', color: '#f97316' },
  { id: 'cat-shopping', name: 'Shopping', type: 'expense', icon: 'ShoppingBag', color: '#ec4899' },
  { id: 'cat-transport', name: 'Transport', type: 'expense', icon: 'Car', color: '#3b82f6' },
  { id: 'cat-bills', name: 'Bills', type: 'expense', icon: 'Receipt', color: '#ef4444' },
  { id: 'cat-education', name: 'Education', type: 'expense', icon: 'GraduationCap', color: '#8b5cf6' },
  { id: 'cat-health', name: 'Health', type: 'expense', icon: 'HeartPulse', color: '#10b981' },
  { id: 'cat-entertainment', name: 'Entertainment', type: 'expense', icon: 'Film', color: '#a855f7' },
  { id: 'cat-travel', name: 'Travel', type: 'expense', icon: 'Plane', color: '#06b6d4' },
  { id: 'cat-personal', name: 'Personal', type: 'expense', icon: 'User', color: '#64748b' },
  { id: 'cat-other-exp', name: 'Other', type: 'expense', icon: 'MoreHorizontal', color: '#94a3b8' },
];

export const DEFAULT_INCOME_CATEGORIES: Category[] = [
  { id: 'cat-salary', name: 'Salary', type: 'income', icon: 'Briefcase', color: '#10b981' },
  { id: 'cat-freelance', name: 'Freelance', type: 'income', icon: 'Laptop', color: '#06b6d4' },
  { id: 'cat-business', name: 'Business', type: 'income', icon: 'Building2', color: '#3b82f6' },
  { id: 'cat-pocket-money', name: 'Pocket Money', type: 'income', icon: 'Coins', color: '#f59e0b' },
  { id: 'cat-gift', name: 'Gift', type: 'income', icon: 'Gift', color: '#ec4899' },
  { id: 'cat-interest', name: 'Interest', type: 'income', icon: 'TrendingUp', color: '#8b5cf6' },
  { id: 'cat-other-inc', name: 'Other', type: 'income', icon: 'Sparkles', color: '#64748b' },
];

export const DEFAULT_ACCOUNTS: Account[] = [
  { id: 'acc-cash', name: 'Cash', type: 'cash', balance: 0, icon: 'Banknote', color: '#10b981' },
  { id: 'acc-bank', name: 'Bank Account', type: 'bank', balance: 0, icon: 'Landmark', color: '#3b82f6' },
];

export const DEFAULT_USER_PROFILE: UserProfile = {
  id: 'guest',
  name: 'MoneyTrack User',
  email: '',
  authProvider: 'email',
  plan: 'FREE',
  subscriptionStatus: 'active',
  currency: { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  language: 'English',
  isDarkMode: false,
  privacyMode: false,
  notificationsEnabled: true,
  hasCompletedOnboarding: false,
};

export const DEFAULT_BUDGETS: CategoryBudget[] = [];

export const DEFAULT_SAVINGS_GOALS: SavingsGoal[] = [];

export const DEFAULT_RECURRING: RecurringTransaction[] = [];

export const DEFAULT_TRANSACTIONS: Transaction[] = [];
