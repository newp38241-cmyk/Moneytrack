export type TransactionType = 'expense' | 'income' | 'transfer';

export type RecurrenceInterval = 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface Category {
  id: string;
  name: string;
  type: 'expense' | 'income';
  icon: string; // Lucide icon name or emoji
  color: string; // Tailwind color or hex
  isCustom?: boolean;
}

export interface Account {
  id: string;
  name: string;
  type: 'cash' | 'bank' | 'upi' | 'wallet' | 'savings' | 'custom';
  balance: number;
  icon: string;
  color: string;
  accountNumber?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  categoryId: string;
  accountId: string;
  toAccountId?: string; // For transfers
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  note?: string;
  attachmentUrl?: string;
  isRecurring?: boolean;
  recurrenceInterval?: RecurrenceInterval;
  createdAt: string;
  updatedAt: string;
}

export interface CategoryBudget {
  categoryId: string;
  amount: number; // Monthly budget limit
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string; // YYYY-MM-DD
  categoryIcon?: string;
  color?: string;
}

export interface RecurringTransaction {
  id: string;
  title: string;
  type: TransactionType;
  amount: number;
  categoryId: string;
  accountId: string;
  interval: RecurrenceInterval;
  nextDueDate: string;
  autoProcess: boolean;
  note?: string;
}

export type SubscriptionPlan = 'FREE' | 'PREMIUM';
export type SubscriptionStatus = 'active' | 'inactive' | 'trial' | 'expired';

export interface UserSubscription {
  userId: string;
  plan: SubscriptionPlan;
  subscriptionStatus: SubscriptionStatus;
  purchaseId?: string;
  startDate?: string;
  expiryDate?: string;
  isDevMock?: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  authProvider?: 'google' | 'email' | 'guest';
  pictureUrl?: string;
  plan: SubscriptionPlan;
  subscriptionStatus: SubscriptionStatus;
  currency: {
    code: string;
    symbol: string;
    name: string;
  };
  language: string;
  isDarkMode: boolean;
  privacyMode: boolean; // Hide amounts with ***
  notificationsEnabled: boolean;
  hasCompletedOnboarding: boolean;
}

export type TimePeriod = 'this_week' | 'this_month' | 'last_month' | 'last_3_months' | 'this_year' | 'custom';

export interface DateRange {
  startDate: string;
  endDate: string;
}
